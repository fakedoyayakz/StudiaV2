(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const o of document.querySelectorAll('link[rel="modulepreload"]'))a(o);new MutationObserver(o=>{for(const l of o)if(l.type==="childList")for(const r of l.addedNodes)r.tagName==="LINK"&&r.rel==="modulepreload"&&a(r)}).observe(document,{childList:!0,subtree:!0});function s(o){const l={};return o.integrity&&(l.integrity=o.integrity),o.referrerPolicy&&(l.referrerPolicy=o.referrerPolicy),o.crossOrigin==="use-credentials"?l.credentials="include":o.crossOrigin==="anonymous"?l.credentials="omit":l.credentials="same-origin",l}function a(o){if(o.ep)return;o.ep=!0;const l=s(o);fetch(o.href,l)}})();const p=e=>document.querySelector(e);window.$=p;const be=(e=180,t=50)=>`
  <svg width="${e}" height="${t}" viewBox="0 0 240 65" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: block;">
    <!-- Light Blue Ribbon/Swoosh flourishes around the text -->
    <path d="M10 24C45 6, 85 45, 128 35C155 28, 175 14, 235 22" stroke="#7ec2f2" stroke-width="2.8" stroke-linecap="round" fill="none" opacity="0.8"/>
    <path d="M124 35C136 43, 155 35, 150 24C145 15, 132 18, 126 27" stroke="#3b82f6" stroke-width="2" stroke-linecap="round" fill="none" opacity="0.9"/>
    
    <!-- Subtle glow on the outer swoosh -->
    <path d="M175 14C195 6, 215 16, 235 22" stroke="#7ec2f2" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round" fill="none" opacity="0.3"/>

    <!-- Book icon matching the user logo -->
    <g transform="translate(68, 2)">
      <!-- Left half -->
      <path d="M15 14C15 6, 25 3, 30 7.5L30 23C25 18, 15 19, 15 22Z" fill="#5B99C2" />
      <!-- Right half -->
      <path d="M45 14C45 6, 35 3, 30 7.5L30 23C35 18, 45 19, 45 22Z" fill="#2E5077" />
      <path d="M18 16C18 13, 24 10, 27 12L27 21" stroke="white" stroke-width="0.8" opacity="0.4" fill="none"/>
      <path d="M42 16C42 13, 36 10, 33 12L33 21" stroke="white" stroke-width="0.8" opacity="0.4" fill="none"/>
    </g>

    <!-- Main Title: Studia -->
    <text x="18" y="47" font-family="'Inter', sans-serif" font-weight="800" font-size="34" fill="#2E5077" letter-spacing="-1.5">Studia</text>
    <!-- Subtitle: GRADE ESCOLAR DIGITAL -->
    <text x="21" y="58" font-family="'Inter', sans-serif" font-weight="700" font-size="8.5" fill="#5B99C2" letter-spacing="1.2">GRADE ESCOLAR DIGITAL</text>
  </svg>
`,W=e=>{const t=p("#app");t&&(t.innerHTML=e,typeof lucide<"u"&&lucide.createIcons())},u=(e,{confirm:t=!1,title:s="Studia"}={})=>new Promise(a=>{var r;const o=document.createElement("div");o.style.cssText="position:fixed;inset:0;z-index:100000;display:flex;align-items:center;justify-content:center;padding:20px;background:rgba(15,23,42,.55);backdrop-filter:blur(5px);font-family:system-ui,sans-serif;",o.innerHTML=`
    <div style="width:min(100%,440px);background:#fff;border:1px solid #e2e8f0;border-radius:16px;box-shadow:0 24px 60px rgba(15,23,42,.25);padding:28px;">
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;color:#2563eb;">
        <div style="width:40px;height:40px;border-radius:10px;background:#eff6ff;display:flex;align-items:center;justify-content:center;font-weight:900;font-size:16px;">S</div>
        <h3 style="margin:0;color:#0f172a;font-size:18px;font-weight:800;">${s}</h3>
      </div>
      <p data-dialog-message style="margin:0;color:#475569;font-size:14px;line-height:1.6;white-space:pre-line;"></p>
      <div style="display:flex;justify-content:flex-end;gap:12px;margin-top:24px;">
        ${t?'<button data-dialog-cancel type="button" style="border:1px solid #e2e8f0;background:#fff;color:#475569;border-radius:10px;padding:11px 20px;font-weight:700;cursor:pointer;transition:all 0.2s;font-size:14px;">Cancelar</button>':""}
        <button data-dialog-ok type="button" style="border:0;background:#2563eb;color:#fff;border-radius:10px;padding:11px 22px;font-weight:700;cursor:pointer;transition:all 0.2s;font-size:14px;box-shadow:0 4px 12px rgba(37,99,235,0.25);">${t?"Confirmar":"Entendi"}</button>
      </div>
    </div>`,o.querySelector("[data-dialog-message]").textContent=e;const l=d=>{o.remove(),a(d)};o.querySelector("[data-dialog-ok]").addEventListener("click",()=>l(!0)),(r=o.querySelector("[data-dialog-cancel]"))==null||r.addEventListener("click",()=>l(!1)),o.addEventListener("click",d=>{d.target===o&&l(!1)}),document.body.appendChild(o),o.querySelector("[data-dialog-ok]").focus()});let i=null;try{const e=localStorage.getItem("user");e&&e!=="undefined"&&e!=="null"&&(i=JSON.parse(e))}catch(e){console.error("Error parsing user from localStorage:",e)}let $=[],O=[],_=[],F=new Set,ue=null,R=[],V=[],G=[],Y="",ee="manha",oe="",T=null,ge=[],ve=[],X={},E={total:0,confirmed:0,absent:0,pending:0},v="horarios",D="closed",U=[],A={date:"",labId:"all",teacher:""},P="all",B="todos",M="todos",K="todos",J="all",le="COLÉGIO ESTADUAL PROF. JÚLIO SZYMANSKI - MATUTINO",me="urania",H="prof_turma",w=localStorage.getItem("reportCardSize")||"medium",we="grid",ye=!1,he=!1,I=(localStorage.getItem("api_base_url")||"").trim();(I==="undefined"||I==="null"||I==="/")&&(I="");const Ne=["localhost","127.0.0.1","::1"].includes(window.location.hostname),_e=window.location.hostname.endsWith(".onrender.com");Ne&&(I="http://localhost:3000",localStorage.removeItem("api_base_url"));_e&&(I="",localStorage.removeItem("api_base_url"));const Ke=!Ne&&!_e;Ke&&(I="https://studia-8st9.onrender.com",localStorage.setItem("api_base_url",I));const Le=e=>{if(e.startsWith("http://")||e.startsWith("https://"))return e;const t=e.startsWith("/")?e:"/"+e;return I?`${I.endsWith("/")?I.slice(0,-1):I}${t}`:t},f={async request(e,t={}){let s=Le(e),a;try{const r={"Content-Type":"application/json",...t.headers};i!=null&&i.accessToken&&(r.Authorization=`Bearer ${i.accessToken}`),a=await fetch(s,{...t,headers:r})}catch(r){console.error("Fetch error on primary URL:",r);let d=null;if(s.includes("ais-pre-")?d=s.replace("ais-pre-","ais-dev-"):s.includes("ais-dev-")&&(d=s.replace("ais-dev-","ais-pre-")),d){console.log("Trying fallback API URL:",d);try{a=await fetch(d,{...t,headers:{"Content-Type":"application/json",...t.headers,...i!=null&&i.accessToken?{Authorization:`Bearer ${i.accessToken}`}:{}}});const n=new URL(d).origin;I=n,localStorage.setItem("api_base_url",n),s=d}catch(c){throw console.error("Fetch error on fallback URL:",c),new Error(`Erro de conexão com o servidor de API.

Tentamos:
1. ${s}
2. ${d}

Verifique se o seu servidor Cloud Run está ativo.`)}}else throw new Error(`Erro de conexão com o servidor de API (${s}).`)}if(a.status===401&&(i!=null&&i.refreshToken)&&!e.startsWith("/api/auth/"))try{const r=await fetch(Le("/api/auth/refresh"),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({refreshToken:i.refreshToken})}),d=await r.json();if(r.ok){i={...i,accessToken:d.accessToken,refreshToken:d.refreshToken},localStorage.setItem("user",JSON.stringify(i));const c={"Content-Type":"application/json",...t.headers,Authorization:`Bearer ${i.accessToken}`};a=await fetch(s,{...t,headers:c})}}catch(r){console.error("Session refresh failed:",r)}if(a.status===401&&i&&!e.startsWith("/api/auth/"))throw localStorage.removeItem("user"),i=null,v="horarios",W(ke()),new Error("Sua sessão não é mais válida. Entre novamente com uma conta ativa para continuar.");const o=await a.text();let l;try{l=JSON.parse(o)}catch(r){throw console.error("Parse error:",r),new Error(`Resposta inválida do servidor de API (${s}).`)}if(!a.ok)throw new Error(l.error||`Erro ${a.status}`);return l},async post(e,t){return this.request(e,{method:"POST",body:JSON.stringify(t)})},async get(e){return this.request(e,{method:"GET"})},async patch(e,t){return this.request(e,{method:"PATCH",body:JSON.stringify(t)})},async delete(e){return this.request(e,{method:"DELETE"})}},ie=e=>{const t=e.split("-");return t.length===3?new Date(parseInt(t[0],10),parseInt(t[1],10)-1,parseInt(t[2],10)):new Date(e)},Ce=e=>{const t=ie(e),s=t.getDay(),a=t.getDate()-s+(s===0?-6:1),o=new Date(t);o.setDate(a);const l=o.getFullYear(),r=String(o.getMonth()+1).padStart(2,"0"),d=String(o.getDate()).padStart(2,"0");return`${l}-${r}-${d}`},$e=e=>{const t=ie(e),s=new Date(t);s.setDate(t.getDate()+4);const a=o=>{const l=String(o.getDate()).padStart(2,"0"),r=String(o.getMonth()+1).padStart(2,"0");return`${l}/${r}`};return`Semana de ${a(t)} a ${a(s)}`},Ye=()=>{const e=new Set;return $.forEach(t=>{if(t.date)try{e.add(Ce(t.date))}catch(s){console.error("Error formatting week:",s)}}),Array.from(e).sort().reverse()},je=(e=$)=>{const t=new Set;return e.forEach(s=>{s.startTime&&t.add(String(s.startTime).slice(0,5))}),Array.from(t).sort()},Te=e=>{if(["manha","tarde","noite"].includes(e.turno))return e.turno;const t=String(e.startTime||"").slice(0,5);return t>="05:00"&&t<"12:00"?"manha":t>="12:00"&&t<"18:00"?"tarde":"noite"},te=(e,t)=>t==="todos"?e:e.filter(s=>Te(s)===t),Z={manha:"Manhã",tarde:"Tarde",noite:"Noite"},Xe=e=>{const t=new Set;return e.forEach(s=>{s.classGroup&&t.add(s.classGroup)}),Array.from(t).sort()},Be=e=>{const t=e.getDay();return t===0?7:t},et=new Map([["programacao front-end","Prog. Front-End"],["programacao back-end","Prog. Back-End"],["programacao back-end i","Prog. Back-End I"],["programacao back-end ii","Prog. Back-End II"],["programacao mobile","Prog. Mobile"],["programacao de desenvolvimento de sistemas","Prog. de Desenv. de Sistemas"],["analise e projeto de sistemas","Análise e Proj. de Sistemas"],["educacao fisica","Ed. Física"],["educacao financeira","Ed. Financeira"],["lingua portuguesa","Língua Port."]]),Ee=e=>{const t=String(e||"").trim();if(!t)return t;const s=t.normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLocaleLowerCase("pt-BR").replace(/\s+/g," ");return et.get(s)||t.replace(/\bprogramação\b/gi,"Prog.").replace(/\bdesenvolvimento\b/gi,"Desenv.").replace(/\beducação\b/gi,"Ed.").replace(/\bportuguesa\b/gi,"Port.").replace(/\bprojeto\b/gi,"Proj.")},re=e=>{if(!e)return e;const t=String(e).trim();return!t||t==="------"?t:t.includes("/")?t.split("/").map(s=>re(s)).join(" / "):t.replace(/\s+/g," ").replace(/^(\d+)([A-Za-zÁÉÍÓÚÀÈÌÒÙÃÕÂÊÎÔÛÇ]+)/u,"$1 $2")},tt=e=>{const t=re(e);return t.split(" - ").map((s,a)=>a===0&&t.includes(" - ")?s:Ee(s)).join(" - ")},Me=(e,t,s,a="prof_turma")=>{const o=["Seg","Ter","Qua","Qui","Sex"],l={};s.forEach(b=>{l[b]={},o.forEach(C=>{l[b][C]="------"})}),t.forEach(b=>{var j,q,N;const C=ie(b.date),y=Be(C),g=y>=1&&y<=5?o[y-1]:null,S=((j=b.startTime)==null?void 0:j.substring(0,5))||b.startTime;if(g&&l[S]){if(b.status!=="confirmed"&&b.status!=="pending"&&((q=b.subject)==null?void 0:q.toUpperCase())!=="HAF")return;const se=((N=b.subject)==null?void 0:N.toUpperCase())==="HAF";let L="------";if(se)L="HAF";else if(a==="prof_turma")L=re(b.classGroup||"------");else if(a==="prof_subject")L=b.subject||"------";else{const ae=b.subject&&e.subject&&b.subject.trim().toLowerCase()!==e.subject.trim().toLowerCase();L=b.classGroup&&ae?`${re(b.classGroup)} - ${b.subject}`:re(b.classGroup||b.subject||"------")}l[S][g]==="------"?l[S][g]=L:l[S][g].split("/").includes(L)||(l[S][g]+="/"+L)}});let r="font-size: 11px; padding: 0.75rem;",d="text-[12px]",c="text-[9.5px]",n="text-[9px]",m="text-[10px]",x="h-9";w==="small"?(r="font-size: 8.5px; padding: 0.5rem;",d="text-[9px]",c="text-[7.5px]",n="text-[7px]",m="text-[7.5px]",x="h-5"):w==="large"?(r="font-size: 13.5px; padding: 1rem;",d="text-[14px]",c="text-[11px]",n="text-[11px]",m="text-[12.5px]",x="h-11"):w==="esticado"?(r="font-size: 15px; padding: 1.25rem;",d="text-[16px]",c="text-[12px]",n="text-[12px]",m="text-[13.5px]",x="h-12"):w==="super_esticado"&&(r="font-size: 18px; padding: 1.75rem;",d="text-[20px]",c="text-[14px]",n="text-[14px]",m="text-[16.5px]",x="h-16");const h=[...new Set(t.map(b=>b.classGroup).filter(Boolean))],k=h.length?` (${h.join(", ")})`:"";return`
    <div class="bg-white border border-[#cbd5e1] rounded-md text-slate-800 shadow-none flex flex-col justify-between break-inside-avoid text-xs w-full min-h-[285px]" style="${r}">
      <div class="mb-1.5 flex flex-wrap justify-between items-center gap-x-2 gap-y-0.5 bg-slate-100 px-2 py-1.5 rounded-sm">
        <span class="min-w-0 flex-1 font-extrabold uppercase text-slate-900 whitespace-normal break-words ${d}">${e.displayName}${k}</span>
        <span title="${e.subject||"Professor"}" class="shrink-0 ${c} text-[#5B99C2] font-extrabold uppercase tracking-tight whitespace-normal break-words">${Ee(e.subject||"Professor")}</span>
      </div>
      <table class="w-full text-center border-collapse table-fixed">
        <thead>
          <tr class="border-b border-slate-200">
            <th class="border border-slate-300 font-semibold text-[#5B99C2] ${n} py-0.5 px-1 text-left w-[48px]">Hor</th>
            ${o.map(b=>`<th class="border border-slate-300 font-bold text-slate-700 ${n} py-0.5 px-1">${b}</th>`).join("")}
          </tr>
        </thead>
        <tbody class="divide-y divide-slate-100">
          ${s.map(b=>`
            <tr class="${x}">
              <td class="border border-slate-300 font-extrabold text-[#2E5077] ${n} text-left py-0.5 px-1">${b}</td>
              ${o.map(C=>{const y=l[b][C];return`<td title="${y}" class="border border-slate-300 ${m} py-0.5 px-1 whitespace-normal break-words ${y==="HAF"?"text-[#5B99C2] font-black":y!=="------"?"text-slate-900 font-black":"text-slate-400"}">${y.split("/").map(tt).join(" / ")}</td>`}).join("")}
            </tr>
          `).join("")}
        </tbody>
      </table>
    </div>
  `},Oe=(e,t,s)=>{console.log(`[DEBUG TurmaScheduleCard] turmaName="${e}", weekSchedules count=${t.length}, slots=${s.join(", ")}`);const a=["Seg","Ter","Qua","Qui","Sex"],o={};s.forEach(h=>{o[h]={},a.forEach(k=>{o[h][k]=null})}),t.forEach(h=>{var g,S;const k=ie(h.date),b=Be(k),C=a[b-1],y=((g=h.startTime)==null?void 0:g.substring(0,5))||h.startTime;if(C&&o[y]){if(h.status!=="confirmed"&&h.status!=="pending"&&((S=h.subject)==null?void 0:S.toUpperCase())!=="HAF")return;const j=O.find(q=>q.uid===h.teacherId);o[y][C]={teacherName:(j==null?void 0:j.displayName)||h.teacherName||"------",subject:h.subject||"------",status:h.status}}});let l="font-size: 11px; padding: 0.75rem;",r="text-[12px]",d="text-[9.5px]",c="text-[9px]",n="text-[10px]",m="text-[8.5px]",x="h-11";return w==="small"?(l="font-size: 8.5px; padding: 0.5rem;",r="text-[9px]",d="text-[7.5px]",c="text-[7px]",n="text-[8.5px]",m="text-[7.5px]",x="h-8"):w==="large"?(l="font-size: 13.5px; padding: 1rem;",r="text-[14px]",d="text-[11px]",c="text-[11px]",n="text-[12.5px]",m="text-[11px]",x="h-16"):w==="esticado"?(l="font-size: 15px; padding: 1.25rem;",r="text-[16px]",d="text-[12px]",c="text-[12px]",n="text-[14px]",m="text-[12px]",x="h-14"):w==="super_esticado"&&(l="font-size: 18px; padding: 1.75rem;",r="text-[20px]",d="text-[14px]",c="text-[14px]",n="text-[17px]",m="text-[14px]",x="h-20"),`
    <div class="bg-white border border-[#cbd5e1] rounded-md text-slate-800 shadow-none flex flex-col justify-between break-inside-avoid text-xs w-full min-h-[285px]" style="${l}">
      <div class="mb-1.5 flex flex-wrap justify-between items-center gap-x-2 bg-slate-100 px-2 py-1.5 rounded-sm">
        <span class="font-extrabold uppercase text-slate-900 truncate ${r}">Turma: ${e}</span>
        <span class="${d} text-[#5B99C2] font-extrabold uppercase tracking-tight">GRADE HORÁRIA</span>
      </div>
      <table class="w-full text-center border-collapse table-fixed">
        <thead>
          <tr class="border-b border-slate-200">
            <th class="border border-slate-300 font-semibold text-[#5B99C2] ${c} py-0.5 px-1 text-left w-[48px]">Hor</th>
            ${a.map(h=>`<th class="border border-slate-300 font-bold text-slate-700 ${c} py-0.5 px-1">${h}</th>`).join("")}
          </tr>
        </thead>
        <tbody class="divide-y divide-slate-100">
          ${s.map(h=>`
            <tr class="${x}">
              <td class="border border-slate-300 font-extrabold text-[#2E5077] ${c} text-left py-0.5 px-1 align-middle">${h}</td>
              ${a.map(k=>{var y;const b=o[h][k];return b?((y=b.subject)==null?void 0:y.toUpperCase())==="HAF"?`
                    <td class="border border-slate-300 py-0.5 px-1 align-middle leading-tight whitespace-normal break-words">
                      <div class="font-black text-[#5B99C2] ${n}">HAF</div>
                    </td>
                  `:`
                  <td class="border border-slate-300 py-0.5 px-1 align-middle leading-tight whitespace-normal break-words">
                    <div class="font-black text-slate-900 whitespace-normal break-words ${n}">${b.teacherName}</div>
                    <div title="${b.subject}" class="text-slate-400 font-extrabold whitespace-normal break-words uppercase mt-0.5 ${m}">${Ee(b.subject)}</div>
                  </td>
                `:`<td class="border border-slate-300 text-slate-300 ${n} py-0.5 px-1 align-middle">------</td>`}).join("")}
            </tr>
          `).join("")}
        </tbody>
      </table>
    </div>
  `},ke=()=>`
  <div style="background: linear-gradient(135deg, #0f172a 0%, #1a1f3a 100%); min-height: 100vh; color: #fff; font-family: system-ui, -apple-system, sans-serif; overflow-x: hidden;">
    <style>
      @keyframes slideInDown { from { opacity: 0; transform: translateY(-20px); } to { opacity: 1; transform: translateY(0); } }
      @keyframes slideInUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
      @keyframes fadeInUp { from { opacity: 0; } to { opacity: 1; } }
      details summary:hover { color: #2563eb !important; }
      @media (max-width: 768px) {
        h1 { font-size: 1.75rem !important; }
        nav > div:nth-child(2) { display: none; }
      }
    </style>

    <!-- Navbar -->
    <nav style="position: fixed; top: 0; left: 0; right: 0; background: rgba(15, 23, 42, 0.8); backdrop-filter: blur(10px); border-bottom: 1px solid rgba(37, 99, 235, 0.1); padding: 1.5rem 2rem; z-index: 40; display: flex; align-items: center; justify-content: space-between;">
      <div style="display: flex; align-items: center; gap: 1rem;">
        ${be(140,40)}
      </div>
      <div style="display: flex; gap: 2rem; align-items: center;">
        <a onclick="document.getElementById('features').scrollIntoView({behavior:'smooth'})" style="color: #94a3b8; text-decoration: none; font-weight: 500; cursor: pointer; transition: all 0.3s; font-size: 0.95rem;">Como Funciona</a>
        <a onclick="document.getElementById('features').scrollIntoView({behavior:'smooth'})" style="color: #94a3b8; text-decoration: none; font-weight: 500; cursor: pointer; transition: all 0.3s; font-size: 0.95rem;">Recursos</a>
        <a onclick="document.getElementById('faq').scrollIntoView({behavior:'smooth'})" style="color: #94a3b8; text-decoration: none; font-weight: 500; cursor: pointer; transition: all 0.3s; font-size: 0.95rem;">FAQ</a>
        <button onclick="actions.showLoginModal('login')" style="background: #2563eb; color: white; border: none; padding: 0.7rem 1.5rem; border-radius: 0.5rem; font-weight: 600; cursor: pointer; transition: all 0.3s;">Acessar Portal</button>
      </div>
    </nav>

    <!-- Hero Section -->
    <section style="padding-top: 8rem; padding-bottom: 4rem; text-align: center; animation: slideInDown 0.8s ease-out;">
      <div style="max-width: 900px; margin: 0 auto; padding: 0 1rem;">
        <div style="background: rgba(37, 99, 235, 0.1); border: 1px solid rgba(37, 99, 235, 0.2); border-radius: 2rem; padding: 0.5rem 1.5rem; display: inline-block; margin-bottom: 2rem;">
          <span style="color: #06b6d4; font-weight: 600; font-size: 0.85rem;">Organização escolar em um só lugar</span>
        </div>
        <h1 style="font-size: 3.5rem; font-weight: 900; line-height: 1.1; margin-bottom: 1.5rem; letter-spacing: -1px;">A rotina da escola<br><span style="background: linear-gradient(135deg, #2563eb, #06b6d4); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;">mais organizada</span><br>e fácil de acompanhar.</h1>
        <p style="font-size: 1.25rem; color: #cbd5e1; margin-bottom: 2.5rem; max-width: 600px; margin-left: auto; margin-right: auto; line-height: 1.6;">Consulte horários, acompanhe as turmas e organize o uso dos laboratórios em uma plataforma simples para professores e direção.</p>
        <div style="display: flex; gap: 1.5rem; justify-content: center; flex-wrap: wrap;">
          <button onclick="actions.showLoginModal('login')" style="background: #2563eb; color: white; border: none; padding: 1.2rem 2.5rem; border-radius: 0.7rem; font-weight: 700; font-size: 1rem; cursor: pointer; transition: all 0.3s; box-shadow: 0 0 30px rgba(37, 99, 235, 0.3);">🎓 Entrar no Portal da Escola</button>
          <button onclick="document.getElementById('features').scrollIntoView({behavior:'smooth'})" style="background: transparent; color: white; border: 2px solid rgba(255, 255, 255, 0.2); padding: 1.2rem 2.5rem; border-radius: 0.7rem; font-weight: 700; font-size: 1rem; cursor: pointer; transition: all 0.3s;">Conhecer recursos</button>
        </div>
        <div style="display: flex; gap: 3rem; justify-content: center; margin-top: 3rem; flex-wrap: wrap; font-weight: 600; font-size: 0.9rem;">
          <div style="color: #cbd5e1;"><span style="color: #06b6d4; font-size: 1.5rem; font-weight: 900;">✓</span> Grade de horários por professor e turma</div>
          <div style="color: #cbd5e1;"><span style="color: #06b6d4; font-size: 1.5rem; font-weight: 900;">✓</span> Reservas de laboratório consultáveis</div>
          <div style="color: #cbd5e1;"><span style="color: #06b6d4; font-size: 1.5rem; font-weight: 900;">✓</span> Acesso pelo navegador</div>
        </div>
      </div>
    </section>

    <!-- Main resources -->
    <section style="background: rgba(15, 23, 42, 0.5); border-top: 1px solid rgba(37, 99, 235, 0.1); border-bottom: 1px solid rgba(37, 99, 235, 0.1); padding: 4rem 2rem; animation: fadeInUp 1s ease-out 0.3s both;">
      <div style="max-width: 1200px; margin: 0 auto; display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 2rem; text-align: center;">
        <div><div style="font-size: 1.25rem; font-weight: 900; color: #2563eb;">Horários</div><div style="color: #94a3b8; font-size: 0.9rem; margin-top: 0.5rem;">Organizados por professor, turma e período</div></div>
        <div><div style="font-size: 1.25rem; font-weight: 900; color: #06b6d4;">Laboratórios</div><div style="color: #94a3b8; font-size: 0.9rem; margin-top: 0.5rem;">Reservas em uma agenda compartilhada da escola</div></div>
        <div><div style="font-size: 1.25rem; font-weight: 900; color: #2563eb;">Relatórios</div><div style="color: #94a3b8; font-size: 0.9rem; margin-top: 0.5rem;">Grades para consulta e impressão</div></div>
      </div>
    </section>

    <!-- Features Section -->
    <section id="features" style="padding: 6rem 2rem; max-width: 1200px; margin: 0 auto;">
      <div style="text-align: center; margin-bottom: 4rem;">
        <div style="color: #06b6d4; font-weight: 700; font-size: 0.9rem; text-transform: uppercase; letter-spacing: 2px; margin-bottom: 1rem;">RECURSOS PARA A ROTINA ESCOLAR</div>
        <h2 style="font-size: 2.5rem; font-weight: 900; margin-bottom: 1rem;">Informações claras para cada pessoa da escola</h2>
        <p style="color: #cbd5e1; font-size: 1.1rem; max-width: 600px; margin: 0 auto;">A direção organiza os dados da escola e cada professor acompanha seus horários e reservas.</p>
      </div>

      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem;">
        <div style="background: rgba(37, 99, 235, 0.05); border: 1px solid rgba(37, 99, 235, 0.2); border-radius: 1.5rem; padding: 2rem; transition: all 0.3s; animation: slideInUp 0.8s ease-out 0.4s both;">
          <div style="width: 50px; height: 50px; background: linear-gradient(135deg, #2563eb, #1e40af); border-radius: 0.75rem; display: flex; align-items: center; justify-content: center; color: white; font-weight: 900; font-size: 1.5rem; margin-bottom: 1.5rem;">⚡</div>
          <h3 style="font-size: 1.25rem; font-weight: 900; margin-bottom: 0.75rem;">Grade de horários</h3>
          <p style="color: #cbd5e1; font-size: 0.95rem; line-height: 1.6;">Consulte e organize os horários de aula com professor, matéria, turma, sala e período.</p>
          <div style="margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid rgba(37, 99, 235, 0.2); color: #06b6d4; font-size: 0.85rem; font-weight: 600;">✓ Visões por professor e turma</div>
        </div>

        <div style="background: rgba(6, 182, 212, 0.05); border: 1px solid rgba(6, 182, 212, 0.2); border-radius: 1.5rem; padding: 2rem; transition: all 0.3s; animation: slideInUp 0.8s ease-out 0.5s both;">
          <div style="width: 50px; height: 50px; background: linear-gradient(135deg, #06b6d4, #0891b2); border-radius: 0.75rem; display: flex; align-items: center; justify-content: center; color: white; font-weight: 900; font-size: 1.5rem; margin-bottom: 1.5rem;">🛡️</div>
          <h3 style="font-size: 1.25rem; font-weight: 900; margin-bottom: 0.75rem;">Espaços Otimizados</h3>
          <p style="color: #cbd5e1; font-size: 0.95rem; line-height: 1.6;">Consulte reservas por data e laboratório e confira os horários já agendados antes de reservar.</p>
          <div style="margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid rgba(6, 182, 212, 0.2); color: #06b6d4; font-size: 0.85rem; font-weight: 600;">✓ Consulta de disponibilidade</div>
        </div>

        <div style="background: rgba(168, 85, 247, 0.05); border: 1px solid rgba(168, 85, 247, 0.2); border-radius: 1.5rem; padding: 2rem; transition: all 0.3s; animation: slideInUp 0.8s ease-out 0.6s both;">
          <div style="width: 50px; height: 50px; background: linear-gradient(135deg, #a855f7, #9333ea); border-radius: 0.75rem; display: flex; align-items: center; justify-content: center; color: white; font-weight: 900; font-size: 1.5rem; margin-bottom: 1.5rem;">📊</div>
          <h3 style="font-size: 1.25rem; font-weight: 900; margin-bottom: 0.75rem;">Acesso por perfil</h3>
          <p style="color: #cbd5e1; font-size: 0.95rem; line-height: 1.6;">Direção e professores encontram ferramentas adequadas às suas atividades e permissões.</p>
          <div style="margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid rgba(168, 85, 247, 0.2); color: #06b6d4; font-size: 0.85rem; font-weight: 600;">✓ Cada perfil vê suas ferramentas</div>
        </div>

        <div style="background: rgba(239, 68, 68, 0.05); border: 1px solid rgba(239, 68, 68, 0.2); border-radius: 1.5rem; padding: 2rem; transition: all 0.3s; animation: slideInUp 0.8s ease-out 0.7s both;">
          <div style="width: 50px; height: 50px; background: linear-gradient(135deg, #ef4444, #dc2626); border-radius: 0.75rem; display: flex; align-items: center; justify-content: center; color: white; font-weight: 900; font-size: 1.5rem; margin-bottom: 1.5rem;">📄</div>
          <h3 style="font-size: 1.25rem; font-weight: 900; margin-bottom: 0.75rem;">Relatórios e impressão</h3>
          <p style="color: #cbd5e1; font-size: 0.95rem; line-height: 1.6;">Gere grades de horários para consultar ou imprimir, com opções de visualização por professor e turma.</p>
          <div style="margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid rgba(239, 68, 68, 0.2); color: #06b6d4; font-size: 0.85rem; font-weight: 600;">✓ Exportação de grades em PDF</div>
        </div>
      </div>
    </section>

    <!-- FAQ -->
    <section id="faq" style="padding: 6rem 2rem; max-width: 900px; margin: 0 auto; border-top: 1px solid rgba(37, 99, 235, 0.1);">
      <div style="text-align: center; margin-bottom: 4rem;">
        <div style="color: #06b6d4; font-weight: 700; font-size: 0.9rem; text-transform: uppercase; letter-spacing: 2px; margin-bottom: 1rem;">PERGUNTAS FREQUENTES</div>
        <h2 style="font-size: 2.5rem; font-weight: 900;">Tire suas dúvidas sobre o Studia</h2>
      </div>
      <div style="space-y: 2rem;">
        <details style="background: rgba(37, 99, 235, 0.05); border: 1px solid rgba(37, 99, 235, 0.2); border-radius: 1rem; padding: 1.5rem; margin-bottom: 1rem; cursor: pointer;">
          <summary style="font-weight: 700; cursor: pointer; color: #fff;">Como consultar os horários da escola?</summary>
          <p style="color: #cbd5e1; margin-top: 1rem; line-height: 1.6;">Depois de entrar no portal, professores consultam seus horários e a direção pode organizar e visualizar a grade da escola.</p>
        </details>

        <details style="background: rgba(37, 99, 235, 0.05); border: 1px solid rgba(37, 99, 235, 0.2); border-radius: 1rem; padding: 1.5rem; margin-bottom: 1rem; cursor: pointer;">
          <summary style="font-weight: 700; cursor: pointer; color: #fff;">Os dados da minha escola são seguros e privados?</summary>
          <p style="color: #cbd5e1; margin-top: 1rem; line-height: 1.6;">As telas e os dados disponíveis dependem do perfil da conta: professor ou direção pedagógica.</p>
        </details>

        <details style="background: rgba(37, 99, 235, 0.05); border: 1px solid rgba(37, 99, 235, 0.2); border-radius: 1rem; padding: 1.5rem; margin-bottom: 1rem; cursor: pointer;">
          <summary style="font-weight: 700; cursor: pointer; color: #fff;">Os professores precisam instalar algum aplicativo pesado?</summary>
          <p style="color: #cbd5e1; margin-top: 1rem; line-height: 1.6;">Não. O portal pode ser acessado pelo navegador do computador ou celular.</p>
        </details>

        <details style="background: rgba(37, 99, 235, 0.05); border: 1px solid rgba(37, 99, 235, 0.2); border-radius: 1rem; padding: 1.5rem; margin-bottom: 1rem; cursor: pointer;">
          <summary style="font-weight: 700; cursor: pointer; color: #fff;">Como reservar um laboratório?</summary>
          <p style="color: #cbd5e1; margin-top: 1rem; line-height: 1.6;">Na aba Laboratórios, consulte as reservas da escola por data e espaço. Ao reservar, o sistema verifica se o horário já está ocupado.</p>
        </details>
      </div>
    </section>

    <!-- Footer -->
    <footer style="background: rgba(15, 23, 42, 0.8); border-top: 1px solid rgba(37, 99, 235, 0.1); padding: 3rem 2rem; text-align: center; color: #94a3b8;">
      <p>© 2026 Studia SaaS — Todos os direitos reservados.</p>
      <p style="margin-top: 1rem; font-size: 0.9rem;">Horários, reservas de laboratório e relatórios para a rotina escolar.</p>
    </footer>

    <!-- Login/Register Modal -->
    <div id="login-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4 ${D==="closed"?"hidden":""}">
      <div class="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onclick="actions.hideLoginModal()"></div>
      <div class="bg-white w-full max-w-md rounded-2xl p-8 relative z-10 shadow-2xl border border-slate-200">
        <div class="flex justify-center mb-6">
          ${be(160,44)}
        </div>
        <div class="flex gap-2 mb-8 bg-slate-100 p-1.5 rounded-xl">
            <button onclick="actions.toggleAuthMode('login')" class="flex-1 py-2 rounded-lg font-bold text-sm transition-all ${D==="login"?"bg-white text-blue-600 shadow-sm":"text-slate-500"}">Entrar</button>
            <button onclick="actions.toggleAuthMode('register')" class="flex-1 py-2 rounded-lg font-bold text-sm transition-all ${D==="register"?"bg-white text-blue-600 shadow-sm":"text-slate-500"}">Criar Conta</button>
        </div>

        <h3 class="text-2xl font-bold mb-2">${D==="login"?"Bem-vindo de volta":"Nova conta Studia"}</h3>
        <div class="space-y-4">
          ${D==="register"?`
            <input type="text" id="auth-name" placeholder="Seu nome completo" class="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none font-medium text-sm text-slate-900">
          `:""}
          <input type="email" id="auth-email" placeholder="nome@escola.pr.gov.br" class="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none font-medium text-sm text-slate-900">
          <input type="password" id="auth-password" placeholder="Sua senha" class="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none font-medium text-sm text-slate-900">

          <button onclick="${D==="login"?"actions.login()":"actions.register()"}" class="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-bold shadow-md shadow-blue-500/15 mt-2 transition-all">
            ${D==="login"?"Entrar":"Cadastrar"}
          </button>
        </div>
      </div>
    </div>
  </div>
`,xe=()=>{const e=te($.filter(o=>o.teacherId===i.uid),K),t=je(e),s=[{id:"horarios",icon:"calendar",label:"Meus Horários"},{id:"labs",icon:"test-tube",label:"Laboratórios"},{id:"materias",icon:"book",label:"Minhas Matérias"}],a={initials:i.displayName?i.displayName.slice(0,2).toUpperCase():"PR",name:i.displayName,subtitle:i.subject||"Professor"};return`
  <div class="flex h-screen overflow-hidden print:overflow-visible flex-col md:flex-row">
    ${Ie({theme:"light",sectionLabel:"Principal",navItems:s,profile:a})}
    ${De({theme:"light",sectionLabel:"Principal",navItems:s,profile:a,drawerId:"mobile-sidebar-drawer"})}

    <main class="flex-1 flex flex-col bg-slate-50 overflow-hidden print:bg-white print:overflow-visible">
      <header class="h-20 bg-white border-b border-slate-200 px-6 md:px-10 flex items-center justify-between shrink-0 print:hidden">
        <div class="flex items-center gap-3">
          <button onclick="actions.toggleMobileMenu(true)" class="md:hidden p-2 -ml-2 text-slate-600 hover:bg-slate-50 rounded-lg" id="btn-toggle-mobile-menu">
            <i data-lucide="menu" class="w-6 h-6"></i>
          </button>
          <h2 class="font-bold text-base md:text-lg capitalize">${v==="horarios"?"Meus Horários":v==="labs"?"Laboratórios":"Minhas Matérias"}</h2>
        </div>
        <div class="flex gap-2">
          ${v==="labs"?`
            <button onclick="actions.showLabModal()" class="bg-blue-600 hover:bg-blue-700 text-white px-3 md:px-5 py-2 md:py-2.5 rounded-lg font-bold flex items-center gap-1.5 md:gap-2 text-xs md:text-sm shadow-md transition-all" id="btn-teacher-lab-new">
              <i data-lucide="plus" class="w-4 h-4 md:w-5 md:h-5"></i> <span>Reservar Lab</span>
            </button>
          `:""}
          <button onclick="actions.refreshSchedules()" class="bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 md:px-5 py-2 md:py-2.5 rounded-lg font-bold flex items-center gap-1.5 md:gap-2 text-xs md:text-sm transition-all" id="btn-refresh-teacher-schedules">
            <i data-lucide="refresh-cw" class="w-4 h-4 md:w-5 md:h-5"></i> <span>Atualizar</span>
          </button>
        </div>
      </header>

      <div class="p-4 md:p-10 flex-1 overflow-y-auto space-y-6 md:space-y-8 print:p-0">
        ${v==="horarios"?`
          <!-- Switch between sub-tabs with counts -->
          <div class="flex gap-2 bg-slate-100 p-1.5 rounded-2xl w-full sm:w-fit mb-6 print:hidden overflow-x-auto scrollbar-none select-none shrink-0">
            <button onclick="actions.setTeacherSchedulesTab('grid')" class="px-5 py-2.5 rounded-lg font-bold text-sm transition-all flex items-center gap-2 whitespace-nowrap ${we==="grid"?"bg-white text-blue-600 shadow-sm":"text-slate-500 hover:text-slate-800"}">
              <i data-lucide="grid-3x3" class="w-4 h-4 text-slate-500"></i> Grade de Horários Completa
            </button>
          </div>

          ${we==="grid"?`
            <!-- Grid Control Box -->
            <div class="bg-white p-6 rounded-3xl border shadow-sm space-y-4 print:hidden">
              <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div class="space-y-1">
                  <label class="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Turno da grade</label>
                  <select onchange="actions.setTeacherTurno(this.value)" class="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    <option value="todos" ${K==="todos"?"selected":""}>Todos os turnos</option>
                    <option value="manha" ${K==="manha"?"selected":""}>Manhã</option>
                    <option value="tarde" ${K==="tarde"?"selected":""}>Tarde</option>
                    <option value="noite" ${K==="noite"?"selected":""}>Noite</option>
                  </select>
                </div>

                <div class="space-y-1">
                  <label class="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Tamanho da Grade</label>
                  <select onchange="actions.setReportCardSize(this.value)" class="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    <option value="small" ${w==="small"?"selected":""}>Pequeno (Compacto)</option>
                    <option value="medium" ${w==="medium"?"selected":""}>Médio (Recomendado)</option>
                    <option value="large" ${w==="large"?"selected":""}>Grande</option>
                    <option value="esticado" ${w==="esticado"?"selected":""}>Descrição Larga</option>
                    <option value="super_esticado" ${w==="super_esticado"?"selected":""}>Página Inteira</option>
                  </select>
                </div>

                <div class="space-y-1">
                  <label class="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Opções Rápidas</label>
                  <button id="btn-download-pdf-teacher" onclick="actions.downloadTeacherPDF()" class="w-full bg-blue-600 hover:bg-blue-700 text-white py-2.5 rounded-lg font-bold text-sm shadow-md flex items-center justify-center gap-1.5 transition-all">
                    <i data-lucide="download" class="w-4 h-4"></i> Baixar PDF
                  </button>
                </div>
              </div>
            </div>

            <!-- Beautiful Grid Sheet Preview -->
            <div class="printable-sheet bg-white border border-slate-200 rounded-[2rem] p-8 md:p-12 shadow-xl relative overflow-hidden">
              <div class="flex flex-col md:flex-row justify-between items-center border-b border-blue-100 pb-6 mb-8 gap-4">
                <div class="flex items-center gap-4">
                  <svg width="240" height="65" viewBox="0 0 240 65" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: block;">
                    <path d="M10 24C45 6, 85 45, 128 35C155 28, 175 14, 235 22" stroke="#7ec2f2" stroke-width="2.8" stroke-linecap="round" fill="none" opacity="0.8"/>
                    <path d="M124 35C136 43, 155 35, 150 24C145 15, 132 18, 126 27" stroke="#3b82f6" stroke-width="2" stroke-linecap="round" fill="none" opacity="0.9"/>
                    <path d="M175 14C195 6, 215 16, 235 22" stroke="#7ec2f2" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round" fill="none" opacity="0.3"/>
                    <g transform="translate(68, 2)">
                      <path d="M15 14C15 6, 25 3, 30 7.5L30 23C25 18, 15 19, 15 22Z" fill="#5B99C2" />
                      <path d="M45 14C45 6, 35 3, 30 7.5L30 23C35 18, 45 19, 45 22Z" fill="#2E5077" />
                      <path d="M18 16C18 13, 24 10, 27 12L27 21" stroke="white" stroke-width="0.8" opacity="0.4" fill="none"/>
                      <path d="M42 16C42 13, 36 10, 33 12L33 21" stroke="white" stroke-width="0.8" opacity="0.4" fill="none"/>
                    </g>
                    <text x="18" y="47" font-family="'Inter', sans-serif" font-weight="800" font-size="34" fill="#2E5077" letter-spacing="-1.5">Studia</text>
                    <text x="21" y="58" font-family="'Inter', sans-serif" font-weight="700" font-size="8.5" fill="#5B99C2" letter-spacing="1.2">GRADE ESCOLAR DIGITAL</text>
                  </svg>
                </div>
                
                <div class="text-center md:text-right">
                  <h4 class="text-sm font-black text-slate-800 uppercase tracking-wide">${le}</h4>
                  <p class="text-[10px] text-slate-400 font-extrabold uppercase tracking-widest mt-1">
                    Grade de Horários Individual do Professor
                  </p>
                </div>
              </div>

              <!-- Center wrapper -->
              <div class="flex justify-center">
                <div class="w-full max-w-2xl overflow-x-auto pb-4 scrollbar-none">
                  <div class="min-w-[550px]">
                    ${Me(i,e,t)}
                  </div>
                </div>
              </div>

              <div class="border-t border-slate-100 mt-12 pt-4 flex justify-end text-[8px] text-slate-400 font-extrabold uppercase tracking-widest leading-none">
                <span>Data de emissão: ${new Date().toLocaleDateString("pt-BR")}</span>
              </div>
            </div>
          `:`
            <!-- Sched List -->
            <div class="grid gap-6">
              ${$.map(o=>`
                <div class="bg-white rounded-3xl p-6 md:p-8 border border-slate-100 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4 md:gap-6 print:shadow-none print:border-slate-300">
                  <div class="flex items-center gap-4 md:gap-6 min-w-0 flex-1">
                    <div class="w-16 text-center border-r pr-4 md:pr-6 shrink-0">
                        <p class="text-lg font-black text-slate-800">${o.startTime}</p>
                    </div>
                    <div class="min-w-0 flex-1">
                      <h3 class="text-base md:text-xl font-black text-slate-900 truncate flex items-center gap-2">
                        ${o.subject}
                        ${o.classGroup?`<span class="bg-blue-100 text-[#2E5077] text-[10px] uppercase font-black px-2 py-0.5 rounded">${o.classGroup}</span>`:""}
                      </h3>
                      <div class="flex flex-wrap items-center gap-3 md:gap-4 mt-1">
                        <span class="text-xs font-bold text-slate-400 flex items-center gap-1 shrink-0"><i data-lucide="map-pin" class="w-3.5 h-3.5"></i> ${o.room}</span>
                        <span class="text-xs font-bold text-slate-400 flex items-center gap-1 shrink-0"><i data-lucide="calendar" class="w-3.5 h-3.5"></i> ${o.date}</span>
                      </div>
                    </div>
                  </div>
                  <div class="flex flex-col gap-3 w-full sm:w-auto sm:min-w-[200px] shrink-0 print:hidden">
                    <div class="text-center py-2 bg-slate-50 rounded-xl border text-[10px] font-black uppercase tracking-widest ${o.status==="confirmed"?"text-blue-600":o.status==="absent"?"text-rose-500":"text-amber-500"}">
                      ${o.status==="confirmed"?"Confirmado":o.status==="absent"?"Ausente":"Pendente"}
                    </div>
                  </div>
                </div>
              `).join("")}
            </div>
          `}
        `:""}
        ${v==="materias"?vt():""}
        ${v==="labs"?Qe():""}
      </div>
    </main>
    
  </div>
  `},st=e=>{const t=O.find(s=>s.uid===e);return t?V.filter(s=>s.school_id===t.school_id&&(s.teacherIds||[]).includes(e)).map(s=>s.subject):[]},Ue=e=>{const t=G.filter(s=>s.turno===e);return t.length?`
    <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
      ${t.map(s=>`
        <label class="flex cursor-pointer items-center gap-2 rounded-lg bg-slate-50 p-2.5 text-sm font-semibold text-slate-700">
          <input type="checkbox" name="form-period" value="${s.periodNumber}" class="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500">
          <span>${s.name} (${String(s.startTime).slice(0,5)}–${String(s.endTime).slice(0,5)})</span>
        </label>
      `).join("")}
    </div>
  `:'<p class="text-sm font-medium text-amber-700">Cadastre os períodos deste turno em Horários → Períodos.</p>'},qe=()=>`
  <div id="create-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4 hidden">
    <div class="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onclick="actions.hideCreateModal()"></div>
    <div class="bg-white w-full max-w-2xl rounded-3xl p-6 md:p-8 relative z-10 shadow-2xl max-h-[92vh] overflow-y-auto">
      <h3 class="text-2xl font-bold mb-6">Montar horário</h3>
      <form onsubmit="actions.createSchedule(event)" class="space-y-4">
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <label class="space-y-1">
            <span class="text-xs font-bold uppercase text-slate-500">Matéria</span>
            <input type="text" id="form-subject" list="form-subject-options" placeholder="Selecione ou digite a matéria" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
            <datalist id="form-subject-options"></datalist>
          </label>
          <label class="space-y-1">
            <span class="text-xs font-bold uppercase text-slate-500">Turma</span>
            <input type="text" id="form-class-group" placeholder="Ex: 9A, 3BI" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
          </label>
        </div>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <label class="space-y-1">
            <span class="text-xs font-bold uppercase text-slate-500">Sala</span>
            <input type="text" id="form-room" placeholder="Sala" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
          </label>
          <label class="space-y-1">
            <span class="text-xs font-bold uppercase text-slate-500">Professor</span>
            <select id="form-teacher" onchange="actions.updateScheduleSubjectOptions(this.value)" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
              <option value="">Selecione o Professor</option>
              ${O.map(e=>`<option value="${e.uid}">${e.displayName}</option>`).join("")}
            </select>
          </label>
        </div>
        <label class="block space-y-1">
          <span class="text-xs font-bold uppercase text-slate-500">Tipo de agendamento</span>
          <select id="form-schedule-mode" onchange="actions.setScheduleCreateMode(this.value)" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm text-slate-900">
            <option value="weekly" selected>Repetir semanalmente no período</option>
            <option value="single">Somente uma data</option>
          </select>
        </label>
        <div id="form-weekly-fields" class="space-y-4">
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <label class="space-y-1">
              <span class="text-xs font-bold uppercase text-slate-500">Data inicial</span>
              <input type="date" id="form-start-date" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm text-slate-900" required>
            </label>
            <label class="space-y-1">
              <span class="text-xs font-bold uppercase text-slate-500">Data final</span>
              <input type="date" id="form-end-date" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm text-slate-900" required>
            </label>
          </div>
          <fieldset class="rounded-xl border border-slate-200 p-3">
            <legend class="px-1 text-xs font-bold uppercase text-slate-500">Dias da semana</legend>
            <div class="flex flex-wrap gap-3">
              ${[["1","Segunda"],["2","Terça"],["3","Quarta"],["4","Quinta"],["5","Sexta"]].map(([e,t])=>`
                <label class="flex items-center gap-2 text-sm font-semibold text-slate-700">
                  <input type="checkbox" name="form-weekday" value="${e}" class="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"> ${t}
                </label>
              `).join("")}
            </div>
          </fieldset>
        </div>
        <div id="form-single-date-field" class="hidden">
          <label class="block space-y-1">
            <span class="text-xs font-bold uppercase text-slate-500">Data da aula</span>
            <input type="date" id="form-date" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm text-slate-900">
          </label>
        </div>
        <label class="block space-y-1">
          <span class="text-xs font-bold uppercase text-slate-500">Turno</span>
          <select id="form-turno" onchange="actions.setScheduleTurno(this.value)" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm text-slate-900">
            <option value="manha">Manhã</option>
            <option value="tarde">Tarde</option>
            <option value="noite">Noite</option>
          </select>
        </label>
        <fieldset class="rounded-xl border border-slate-200 p-3">
          <legend class="px-1 text-xs font-bold uppercase text-slate-500">Períodos da aula</legend>
          <div id="form-period-options">${Ue("manha")}</div>
          <p class="mt-2 text-xs text-slate-500">A 6ª aula será criada somente nos dias da semana que você selecionar acima.</p>
        </fieldset>
        <div class="flex gap-4 pt-2">
          <button type="button" onclick="actions.hideCreateModal()" class="flex-1 py-2.5 border border-slate-200 rounded-lg font-bold hover:bg-slate-50 transition-all text-slate-700">Cancelar</button>
          <button type="submit" ${G.length?"":"disabled"} class="flex-1 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white py-2.5 rounded-lg font-bold shadow-md transition-all">Gerar horários</button>
        </div>
      </form>
    </div>
  </div>
`,at=()=>`
  <div id="school-periods-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4 hidden">
    <div class="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onclick="actions.hideSchoolPeriodsModal()"></div>
    <div class="bg-white w-full max-w-2xl rounded-3xl p-6 md:p-8 relative z-10 shadow-2xl max-h-[92vh] overflow-y-auto">
      <div class="flex items-start justify-between gap-4 mb-6">
        <div>
          <h3 class="text-2xl font-bold">Períodos da escola</h3>
          <p class="mt-1 text-sm text-slate-500">Configure uma vez os horários que serão usados nas grades.</p>
        </div>
        <button type="button" onclick="actions.hideSchoolPeriodsModal()" class="rounded-lg p-2 text-slate-500 hover:bg-slate-100" aria-label="Fechar">✕</button>
      </div>
      ${Y?`<p class="mb-4 rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm font-medium text-amber-800">${Y}</p>`:""}
      <form onsubmit="actions.saveSchoolPeriod(event)" class="grid grid-cols-1 sm:grid-cols-4 gap-3 rounded-xl bg-slate-50 p-4">
        <select id="period-turno" onchange="actions.setPeriodAdminTurno(this.value)" class="w-full rounded-lg border border-slate-200 bg-white p-2.5 text-sm" aria-label="Turno do período">
          <option value="manha" ${ee==="manha"?"selected":""}>Manhã</option>
          <option value="tarde" ${ee==="tarde"?"selected":""}>Tarde</option>
          <option value="noite" ${ee==="noite"?"selected":""}>Noite</option>
        </select>
        <input id="period-name" type="text" placeholder="Nome (ex.: 1ª aula)" class="sm:col-span-2 w-full rounded-lg border border-slate-200 bg-white p-2.5 text-sm" required>
        <input id="period-start" type="time" class="w-full rounded-lg border border-slate-200 bg-white p-2.5 text-sm" required>
        <input id="period-end" type="time" class="w-full rounded-lg border border-slate-200 bg-white p-2.5 text-sm" required>
        <button type="submit" class="sm:col-span-4 rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-bold text-white hover:bg-blue-700">Adicionar ao turno selecionado</button>
      </form>
      <div class="mt-5 space-y-6">
        ${["manha","tarde","noite"].map(e=>{const t=G.filter(s=>s.turno===e);return`
            <section class="space-y-3">
              <h4 class="text-sm font-black uppercase tracking-wide text-slate-700">${Z[e]} <span class="font-medium normal-case text-slate-400">${e!=="noite"?"(até 6 aulas)":"(até 5 aulas)"}</span></h4>
              ${t.map(s=>`
                <form onsubmit="actions.updateSchoolPeriod(event, ${s.id})" class="grid grid-cols-1 sm:grid-cols-[1fr_125px_125px_auto_auto] items-center gap-2 rounded-xl border border-slate-200 p-3">
                  <input id="period-name-${s.id}" type="text" value="${s.name}" class="w-full rounded-lg border border-slate-200 p-2 text-sm" aria-label="Nome do período" required>
                  <input id="period-start-${s.id}" type="time" value="${String(s.startTime).slice(0,5)}" class="w-full rounded-lg border border-slate-200 p-2 text-sm" aria-label="Início" required>
                  <input id="period-end-${s.id}" type="time" value="${String(s.endTime).slice(0,5)}" class="w-full rounded-lg border border-slate-200 p-2 text-sm" aria-label="Término" required>
                  <button type="submit" class="rounded-lg bg-slate-900 px-3 py-2 text-xs font-bold text-white">Salvar</button>
                  <button type="button" onclick="actions.deleteSchoolPeriod(${s.id})" class="rounded-lg border border-rose-200 px-3 py-2 text-xs font-bold text-rose-600">Excluir</button>
                </form>
              `).join("")||'<p class="rounded-lg bg-slate-50 p-3 text-sm text-slate-400">Nenhum período cadastrado neste turno.</p>'}
            </section>
          `}).join("")}
      </div>
    </div>
  </div>
`,Fe=()=>`
  <div id="edit-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4 hidden">
    <div class="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onclick="actions.hideEditModal()"></div>
    <div class="bg-white w-full max-w-lg rounded-3xl p-8 relative z-10 shadow-2xl overflow-y-auto max-h-[90vh]">
      <h3 class="text-2xl font-bold mb-6 text-slate-800">Editar Horário</h3>
      <form onsubmit="actions.updateSchedule(event)" class="space-y-4">
        <input type="hidden" id="edit-form-id">
        <div class="grid grid-cols-2 gap-4">
          <div>
            <label class="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Matéria</label>
            <input type="text" id="edit-form-subject" list="edit-form-subject-options" placeholder="Selecione ou digite a matéria" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
            <datalist id="edit-form-subject-options"></datalist>
          </div>
          <div>
            <label class="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Turma</label>
            <input type="text" id="edit-form-class-group" placeholder="Turma (ex: 9A, 3BI)" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
          </div>
        </div>
        <div class="grid grid-cols-2 gap-4">
          <div>
            <label class="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Data</label>
            <input type="date" id="edit-form-date" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
          </div>
          <div>
            <label class="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Sala / Local</label>
            <input type="text" id="edit-form-room" placeholder="Sala" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
          </div>
        </div>
        <label class="block">
          <span class="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Turno</span>
          <select id="edit-form-turno" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm text-slate-900" required>
            <option value="manha">Manhã</option>
            <option value="tarde">Tarde</option>
            <option value="noite">Noite</option>
          </select>
        </label>
        <div class="grid grid-cols-2 gap-4">
          <div>
            <label class="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Hora Início</label>
            <input type="time" id="edit-form-start" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
          </div>
          <div>
            <label class="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Hora Término</label>
            <input type="time" id="edit-form-end" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
          </div>
        </div>
        <div>
          <label class="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Professor</label>
          <select id="edit-form-teacher" onchange="actions.updateScheduleSubjectOptions(this.value, '', 'edit-form')" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
            <option value="">Selecione o Professor</option>
            ${O.map(e=>`<option value="${e.uid}">${e.displayName}</option>`).join("")}
          </select>
        </div>
        <div>
          <label class="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Status</label>
          <select id="edit-form-status" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
            <option value="pending">Pendente</option>
            <option value="confirmed">Confirmado</option>
            <option value="absent">Falta / Ausente</option>
          </select>
        </div>
        <div class="flex gap-4 pt-4">
          <button type="button" onclick="actions.hideEditModal()" class="flex-1 py-2.5 border border-slate-200 rounded-lg font-bold hover:bg-slate-50 transition-all text-slate-700">Cancelar</button>
          <button type="submit" class="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2.5 rounded-lg font-bold shadow-md transition-all">Salvar</button>
        </div>
      </form>
    </div>
  </div>
`,Ge=()=>`
  <div id="delete-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4 hidden">
    <div class="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onclick="actions.hideDeleteModal()"></div>
    <div class="bg-white w-full max-w-sm rounded-[2rem] p-6 relative z-10 shadow-2xl border border-slate-100">
      <div class="flex items-center gap-3 mb-4 text-rose-600">
        <div class="bg-rose-50 p-2.5 rounded-2xl">
          <i data-lucide="alert-triangle" class="w-6 h-6"></i>
        </div>
        <h3 class="text-lg font-black text-slate-800">Confirmar Exclusão</h3>
      </div>
      <p class="text-xs text-slate-500 mb-6 leading-relaxed">Você tem certeza de que deseja excluir este horário? Esta ação não poderá ser desfeita.</p>
      <input type="hidden" id="delete-schedule-id">
      <div class="flex gap-3">
        <button onclick="actions.hideDeleteModal()" class="flex-1 py-3 text-xs font-bold text-slate-600 border rounded-xl hover:bg-slate-50 transition-all">Cancelar</button>
        <button onclick="actions.confirmDeleteSchedule()" class="flex-1 py-3 text-xs font-bold text-white bg-rose-600 rounded-xl hover:bg-rose-700 shadow-lg shadow-rose-600/10 transition-all">Excluir</button>
      </div>
    </div>
  </div>
`,ot=()=>`
  <div id="lab-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4 hidden">
    <div class="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onclick="actions.hideLabModal()"></div>
    <div class="bg-white w-full max-w-lg rounded-3xl p-8 relative z-10 shadow-2xl">
      <h3 class="text-2xl font-bold mb-8">Reservar Laboratório</h3>
      <form onsubmit="actions.createLabBooking(event)" class="space-y-4">
        <p class="text-sm text-slate-500">Confira as reservas da escola na agenda para escolher um horário disponível.</p>
        <label class="block">
          <span class="mb-1.5 block text-xs font-bold uppercase text-slate-500">Laboratório</span>
          <select id="lab-type" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
            <option value="info">Informática</option>
            <option value="chem">Química</option>
          </select>
        </label>
        <label class="block">
          <span class="mb-1.5 block text-xs font-bold uppercase text-slate-500">Data</span>
          <input type="date" id="lab-date" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
        </label>
        <div class="grid grid-cols-2 gap-4">
          <label class="block">
            <span class="mb-1.5 block text-xs font-bold uppercase text-slate-500">Início</span>
            <input type="time" id="lab-start" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
          </label>
          <label class="block">
            <span class="mb-1.5 block text-xs font-bold uppercase text-slate-500">Término</span>
            <input type="time" id="lab-end" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
          </label>
        </div>
        <div class="flex gap-4 pt-4">
          <button type="button" onclick="actions.hideLabModal()" class="flex-1 py-2.5 border border-slate-200 rounded-lg font-bold hover:bg-slate-50 transition-all text-slate-700">Cancelar</button>
          <button type="submit" class="flex-1 bg-slate-900 hover:bg-slate-800 text-white py-2.5 rounded-lg font-bold shadow-md transition-all">Reservar</button>
        </div>
      </form>
    </div>
  </div>
`,rt=()=>`
  <div id="create-escola-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4 hidden">
    <div class="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onclick="actions.hideCreateEscolaModal()"></div>
    <div class="bg-white w-full max-w-md rounded-2xl p-8 relative z-10 shadow-2xl border border-slate-200">
      <h3 class="text-2xl font-bold mb-6">Criar Nova Escola</h3>
      <form onsubmit="actions.createSchool(event)" class="space-y-4">
        <div>
          <label class="text-xs font-bold text-slate-500 uppercase block mb-2">Nome da Escola</label>
          <input type="text" id="escola-name" placeholder="Ex: Colégio Estadual..." class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
        </div>
        <div class="flex gap-4 pt-4">
          <button type="button" onclick="actions.hideCreateEscolaModal()" class="flex-1 py-2.5 border border-slate-200 rounded-lg font-bold hover:bg-slate-50 transition-all text-slate-700">Cancelar</button>
          <button type="submit" class="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2.5 rounded-lg font-bold shadow-md transition-all">Criar</button>
        </div>
      </form>
    </div>
  </div>
`,He=({viewerRole:e="dev"}={})=>`
  <div id="create-user-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4 hidden">
    <div class="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onclick="actions.hideCreateUserModal()"></div>
    <div class="bg-white w-full max-w-md rounded-2xl p-8 relative z-10 shadow-2xl border border-slate-200">
      <h3 class="text-2xl font-bold mb-6">Criar Novo Usuário</h3>
      <form onsubmit="actions.createUser(event)" class="space-y-4">
        <div>
          <label class="text-xs font-bold text-slate-500 uppercase block mb-2">Nome</label>
          <input type="text" id="user-displayname" placeholder="Ex: João Silva" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
        </div>
        <div>
          <label class="text-xs font-bold text-slate-500 uppercase block mb-2">E-mail</label>
          <input type="email" id="user-email" placeholder="Ex: joao@example.com" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
        </div>
        <div>
          <label class="text-xs font-bold text-slate-500 uppercase block mb-2">Senha</label>
          <input type="password" id="user-password" placeholder="Mínimo 8 caracteres" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required minlength="8">
        </div>
        ${e==="dev"?`
          <div>
            <label class="text-xs font-bold text-slate-500 uppercase block mb-2">Escola</label>
            <select id="user-school" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
              <option value="">Selecione uma escola</option>
              ${R.map(t=>`<option value="${t.id}">${t.name}</option>`).join("")}
            </select>
          </div>
        `:""}
        <div>
          <label class="text-xs font-bold text-slate-500 uppercase block mb-2">Matérias</label>
          <input type="text" id="user-subject" placeholder="Ex: Matemática, Física, Química" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900">
        </div>
        <div>
          <label class="text-xs font-bold text-slate-500 uppercase block mb-2">Cargo</label>
          <select id="user-role" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
            ${e==="dev"?`
                <option value="">Selecione um cargo</option>
                <option value="teacher">Professor</option>
                <option value="diretor">Diretor / Direção Pedagógica</option>
                <option value="dev">Desenvolvedor</option>
              `:`
                <option value="">Selecione um cargo</option>
                <option value="teacher">Professor</option>
                <option value="diretor">Diretor / Direção Pedagógica</option>
              `}
          </select>
        </div>
        <div class="flex gap-4 pt-4">
          <button type="button" onclick="actions.hideCreateUserModal()" class="flex-1 py-2.5 border border-slate-200 rounded-lg font-bold hover:bg-slate-50 transition-all text-slate-700">Cancelar</button>
          <button type="submit" class="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2.5 rounded-lg font-bold shadow-md transition-all">Criar</button>
        </div>
      </form>
    </div>
  </div>
`,lt=()=>{const e=!!(T!=null&&T.api.ok)&&!!(T!=null&&T.database.ok),t=$.length,s=_.length,a=U.length;return`
    <div class="space-y-6">
      <div class="flex flex-col gap-2 md:flex-row md:items-end md:justify-between">
        <div>
          <h3 class="text-2xl font-black text-slate-900">Visão geral da plataforma</h3>
          <p class="text-sm text-slate-500 font-medium">Monitoramento da API, usuários e dados operacionais do site.</p>
        </div>
        <div class="inline-flex items-center gap-2 rounded-full ${e?"bg-emerald-50 text-emerald-700":"bg-amber-50 text-amber-700"} px-3 py-1.5 text-xs font-black uppercase tracking-[0.18em]">
          <i data-lucide="database" class="w-3.5 h-3.5"></i> ${e?"Supabase online":"Modo local"}
        </div>
      </div>

      <div class="grid md:grid-cols-2 xl:grid-cols-4 gap-4">
        <div class="bg-white rounded-3xl border border-slate-200 p-5 shadow-sm">
          <div class="flex items-center justify-between">
            <p class="text-[10px] font-black uppercase tracking-[0.18em] text-slate-400">Status</p>
            <span class="w-2.5 h-2.5 rounded-full ${e?"bg-emerald-500":"bg-amber-400"}"></span>
          </div>
          <p class="mt-5 text-3xl font-black text-slate-900">${e?"OK":"Local"}</p>
          <p class="mt-2 text-sm text-slate-500">Conexão com a API express</p>
        </div>
        <div class="bg-white rounded-3xl border border-slate-200 p-5 shadow-sm">
          <div class="flex items-center justify-between">
            <p class="text-[10px] font-black uppercase tracking-[0.18em] text-slate-400">Usuários</p>
            <i data-lucide="users" class="w-4 h-4 text-blue-600"></i>
          </div>
          <p class="mt-5 text-3xl font-black text-slate-900">${s}</p>
          <p class="mt-2 text-sm text-slate-500">Contas cadastradas</p>
        </div>
        <div class="bg-white rounded-3xl border border-slate-200 p-5 shadow-sm">
          <div class="flex items-center justify-between">
            <p class="text-[10px] font-black uppercase tracking-[0.18em] text-slate-400">Horários</p>
            <i data-lucide="calendar" class="w-4 h-4 text-violet-600"></i>
          </div>
          <p class="mt-5 text-3xl font-black text-slate-900">${t}</p>
          <p class="mt-2 text-sm text-slate-500">Registros no banco</p>
        </div>
        <div class="bg-white rounded-3xl border border-slate-200 p-5 shadow-sm">
          <div class="flex items-center justify-between">
            <p class="text-[10px] font-black uppercase tracking-[0.18em] text-slate-400">Labs</p>
            <i data-lucide="beaker" class="w-4 h-4 text-emerald-600"></i>
          </div>
          <p class="mt-5 text-3xl font-black text-slate-900">${a}</p>
          <p class="mt-2 text-sm text-slate-500">Reservas registradas</p>
        </div>
      </div>

      <div class="grid xl:grid-cols-[1.1fr_0.9fr] gap-6">
        <div class="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm">
          <h4 class="text-lg font-black text-slate-900">Infraestrutura do projeto</h4>
          <div class="mt-5 space-y-4">
            <div class="flex justify-between items-center border-b border-slate-100 pb-3">
              <span class="text-sm font-semibold text-slate-500">Banco de dados</span>
              <span class="text-sm font-black text-slate-900">Supabase Postgres</span>
            </div>
            <div class="flex justify-between items-center border-b border-slate-100 pb-3">
              <span class="text-sm font-semibold text-slate-500">Autenticação</span>
              <span class="text-sm font-black text-slate-900">Auth + RLS</span>
            </div>
            <div class="flex justify-between items-center border-b border-slate-100 pb-3">
              <span class="text-sm font-semibold text-slate-500">API</span>
              <span class="text-sm font-black text-slate-900">Express + Vite</span>
            </div>
          </div>
        </div>

        <div class="bg-slate-900 rounded-3xl p-6 shadow-lg text-white">
          <div class="flex items-center justify-between">
            <h4 class="text-lg font-black">Environment</h4>
            <span class="inline-flex items-center gap-2 rounded-full bg-white/10 px-2.5 py-1 text-[10px] font-black uppercase tracking-[0.18em] text-slate-200">
              <i data-lucide="shield-check" class="w-3.5 h-3.5"></i> Seguro
            </span>
          </div>
          <div class="mt-5 space-y-4 text-sm text-slate-300">
            <div class="rounded-2xl bg-white/5 p-3">
              <p class="text-[10px] uppercase tracking-[0.18em] text-slate-400">API base</p>
              <p class="mt-1 font-semibold break-all">${I||"http://localhost:3000"}</p>
            </div>
            <div class="rounded-2xl bg-white/5 p-3">
              <p class="text-[10px] uppercase tracking-[0.18em] text-slate-400">Proteção</p>
              <p class="mt-1 font-semibold">Service role no backend apenas</p>
            </div>
            <div class="rounded-2xl bg-white/5 p-3">
              <p class="text-[10px] uppercase tracking-[0.18em] text-slate-400">Armazenamento</p>
              <p class="mt-1 font-semibold">Usuários, horários, laboratórios e certificados</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  `},z=e=>String(e??"").replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t]),ne=()=>`
  <button onclick="actions.refreshDeveloperPanel()" class="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-bold text-white hover:bg-slate-800">
    <i data-lucide="refresh-cw" class="h-4 w-4"></i> Atualizar
  </button>
`,de=e=>X[e]?`
  <div class="rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm font-semibold text-rose-700">${z(X[e])}</div>
`:"",it=()=>{const e=T,t=e==null?void 0:e.api.ok,s=e==null?void 0:e.database.ok;return`
    <div class="space-y-6">
      <header class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h3 class="text-2xl font-black text-slate-900">Saúde do sistema</h3>
          <p class="mt-1 text-sm font-medium text-slate-500">Estado atual da API e conexão com o banco de dados.</p>
        </div>
        ${ne()}
      </header>
      ${de("diagnostics")}
      <div class="grid gap-4 md:grid-cols-3">
        ${[{title:"API",ok:t,detail:t===void 0?"Aguardando verificação":t?"Respondendo normalmente":"Indisponível"},{title:"Banco de dados",ok:s,detail:s===void 0?"Aguardando verificação":s?`${e.database.latencyMs} ms de resposta`:"Falha ao consultar o banco"},{title:"Tempo ativo",ok:t,detail:e?`${Math.floor(e.uptimeSeconds/60)} min`:"Aguardando verificação"}].map(a=>`
          <article class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <div class="flex items-center justify-between">
              <h4 class="font-black text-slate-800">${a.title}</h4>
              <span class="rounded-full px-3 py-1 text-xs font-black ${a.ok===void 0?"bg-slate-100 text-slate-500":a.ok?"bg-emerald-100 text-emerald-700":"bg-rose-100 text-rose-700"}">${a.ok===void 0?"PENDENTE":a.ok?"OK":"FALHA"}</span>
            </div>
            <p class="mt-4 text-sm font-semibold text-slate-500">${a.detail}</p>
          </article>
        `).join("")}
      </div>
      ${e?`<p class="text-xs font-medium text-slate-400">Verificado em ${new Date(e.checkedAt).toLocaleString("pt-BR")}.</p>`:""}
    </div>
  `},nt=()=>`
  <div class="space-y-6">
    <header class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <h3 class="text-2xl font-black text-slate-900">Diagnóstico</h3>
        <p class="mt-1 text-sm font-medium text-slate-500">Testes de leitura nas tabelas e verificações básicas de integridade.</p>
      </div>
      ${ne()}
    </header>
    ${de("diagnostics")}
    <section class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
      <h4 class="border-b border-slate-100 p-5 font-black text-slate-800">Conexão e latência por tabela</h4>
      ${T?`
        <div class="overflow-x-auto">
          <table class="w-full min-w-[560px] text-left text-sm">
            <thead class="bg-slate-50 text-xs uppercase text-slate-400"><tr><th class="px-5 py-3">Tabela</th><th class="px-5 py-3">Status</th><th class="px-5 py-3">Registros</th><th class="px-5 py-3">Resposta</th></tr></thead>
            <tbody class="divide-y divide-slate-100">
              ${T.probes.map(e=>`
                <tr>
                  <td class="px-5 py-3 font-semibold text-slate-700">${z(e.table)}</td>
                  <td class="px-5 py-3 font-bold ${e.ok?"text-emerald-700":"text-rose-700"}">${e.ok?"OK":"Falha"}</td>
                  <td class="px-5 py-3 text-slate-600">${e.records??"—"}</td>
                  <td class="px-5 py-3 text-slate-600">${e.latencyMs} ms</td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      `:'<p class="p-5 text-sm font-medium text-slate-500">Atualize para executar os testes.</p>'}
    </section>
    <section class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <h4 class="font-black text-slate-800">Integridade básica</h4>
      <div class="mt-4 grid gap-3 md:grid-cols-2">
        ${((T==null?void 0:T.integrity)||[]).map(e=>`
          <div class="flex items-center justify-between gap-4 rounded-xl bg-slate-50 p-4">
            <span class="text-sm font-semibold text-slate-600">${z(e.name)}</span>
            <span class="text-sm font-black ${e.ok&&e.count===0?"text-emerald-700":"text-amber-700"}">${e.ok?e.count:"Erro na consulta"}</span>
          </div>
        `).join("")}
        ${T?"":'<p class="text-sm text-slate-500">Os resultados aparecerão após a verificação.</p>'}
      </div>
    </section>
  </div>
`,dt=()=>`
  <div class="space-y-6">
    <header class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <h3 class="text-2xl font-black text-slate-900">Logs de erros</h3>
        <p class="mt-1 text-sm font-medium text-slate-500">Últimos 100 erros HTTP 5xx registrados pela API. O conteúdo dos pedidos não é armazenado.</p>
      </div>
      ${ne()}
    </header>
    ${de("logs")}
    <section class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
      ${ve.length?`
        <div class="overflow-x-auto">
          <table class="w-full min-w-[620px] text-left text-sm">
            <thead class="bg-slate-50 text-xs uppercase text-slate-400"><tr><th class="px-5 py-3">Data</th><th class="px-5 py-3">Método</th><th class="px-5 py-3">Rota</th><th class="px-5 py-3">Código</th></tr></thead>
            <tbody class="divide-y divide-slate-100">
              ${ve.map(e=>`
                <tr><td class="px-5 py-3 text-slate-600">${new Date(e.created_at).toLocaleString("pt-BR")}</td><td class="px-5 py-3 font-bold text-slate-700">${z(e.method)}</td><td class="px-5 py-3 font-mono text-xs text-slate-600">${z(e.route)}</td><td class="px-5 py-3 font-black text-rose-700">${z(e.status_code)}</td></tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      `:'<p class="p-5 text-sm font-medium text-slate-500">Nenhum erro registrado ou ainda não há logs disponíveis.</p>'}
    </section>
  </div>
`,ct=()=>`
  <div class="space-y-6">
    <header class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <h3 class="text-2xl font-black text-slate-900">Auditoria</h3>
        <p class="mt-1 text-sm font-medium text-slate-500">Últimas 100 alterações concluídas, com usuário, rota e horário.</p>
      </div>
      ${ne()}
    </header>
    ${de("audit")}
    <section class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
      ${ge.length?`
        <div class="overflow-x-auto">
          <table class="w-full min-w-[760px] text-left text-sm">
            <thead class="bg-slate-50 text-xs uppercase text-slate-400"><tr><th class="px-5 py-3">Data</th><th class="px-5 py-3">Usuário</th><th class="px-5 py-3">Ação</th><th class="px-5 py-3">Rota</th><th class="px-5 py-3">Resultado</th></tr></thead>
            <tbody class="divide-y divide-slate-100">
              ${ge.map(e=>`
                <tr><td class="px-5 py-3 text-slate-600">${new Date(e.created_at).toLocaleString("pt-BR")}</td><td class="px-5 py-3 font-mono text-xs text-slate-600">${z(e.actor_uid)} <span class="font-sans">(${z(e.actor_role)})</span></td><td class="px-5 py-3 font-bold text-slate-700">${z(e.method)}</td><td class="px-5 py-3 font-mono text-xs text-slate-600">${z(e.route)}</td><td class="px-5 py-3 font-semibold text-emerald-700">${z(e.status_code)}</td></tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      `:'<p class="p-5 text-sm font-medium text-slate-500">Nenhuma alteração registrada ou ainda não há eventos disponíveis.</p>'}
    </section>
  </div>
`,pt=()=>`
  <div class="space-y-6">
    <header class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <h3 class="text-2xl font-black text-slate-900">Dados e backups</h3>
        <p class="mt-1 text-sm font-medium text-slate-500">Consulte volumes e exporte dados selecionados da plataforma.</p>
      </div>
      ${ne()}
    </header>
    ${de("diagnostics")}
    <section class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <h4 class="font-black text-slate-800">Registros por tabela</h4>
      <div class="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        ${((T==null?void 0:T.probes)||[]).map(e=>`
          <div class="rounded-xl bg-slate-50 p-4">
            <p class="text-xs font-bold uppercase text-slate-400">${z(e.table)}</p>
            <p class="mt-2 text-2xl font-black text-slate-800">${e.ok?e.records:"Consulta falhou"}</p>
          </div>
        `).join("")}
        ${T?"":'<p class="text-sm text-slate-500">Atualize para consultar as tabelas.</p>'}
      </div>
    </section>
    <section class="rounded-2xl border border-amber-200 bg-amber-50 p-5">
      <h4 class="font-black text-amber-900">Exportação CSV</h4>
      <p class="mt-1 text-sm text-amber-800">Os arquivos podem conter dados pessoais. Escolha uma tabela e confirme antes de baixar; cada exportação tem limite de 5.000 registros.</p>
      <div class="mt-4 flex flex-col gap-3 sm:flex-row">
        <select id="dev-export-resource" class="rounded-xl border border-amber-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700">
          <option value="users">Usuários</option>
          <option value="schools">Escolas</option>
          <option value="schedules">Horários</option>
          <option value="school_periods">Períodos escolares</option>
          <option value="lab_bookings">Reservas de laboratório</option>
          <option value="school_subjects">Matérias da escola</option>
          <option value="teacher_subjects">Vínculos de matérias</option>
        </select>
        <button onclick="actions.exportDeveloperData()" class="rounded-xl bg-amber-700 px-5 py-2.5 text-sm font-bold text-white hover:bg-amber-800">Exportar CSV</button>
      </div>
    </section>
    <section class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <h4 class="font-black text-slate-800">Backup e restauração</h4>
      <p class="mt-2 text-sm leading-6 text-slate-600">Backups completos devem ser criados e restaurados pelo painel do Supabase, que controla a retenção e os snapshots do projeto. Antes de uma alteração estrutural, confira o backup mais recente e teste a restauração em um ambiente separado.</p>
      <a href="https://supabase.com/dashboard" target="_blank" rel="noopener noreferrer" class="mt-4 inline-flex items-center gap-2 font-bold text-blue-700 hover:text-blue-800">Abrir painel do Supabase <i data-lucide="external-link" class="h-4 w-4"></i></a>
    </section>
  </div>
`,ut=(e,t,s)=>`
  <button onclick="actions.switchTab('${e}')"
    class="w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-semibold ${v===e?"bg-white/10 text-white font-bold":"text-slate-400 hover:bg-white/5 hover:text-white"}">
    <i data-lucide="${t}"></i> ${s}
  </button>
`,mt=(e,t,s)=>`
  <button onclick="actions.switchTab('${e}')"
    class="w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-semibold ${v===e?"bg-blue-50 text-blue-700 font-bold border-l-2 border-blue-600":"text-slate-500 hover:bg-slate-50 hover:text-slate-800"}">
    <i data-lucide="${t}"></i> ${s}
  </button>
`,Ie=({theme:e="light",sectionLabel:t,navItems:s,profile:a})=>{const o=e==="dark",l=o?ut:mt;return`
    <aside class="w-64 border-r ${o?"bg-slate-900 border-slate-800 text-slate-300":"bg-white border-slate-200 text-slate-500"} hidden md:flex flex-col p-6 print:hidden shrink-0">
      <div class="flex items-center mb-10 px-2 shrink-0">${be(170,46)}</div>
      <p class="text-[10px] font-bold ${o?"text-slate-500":"text-slate-400"} uppercase tracking-widest mb-4 px-4">${t}</p>
      <nav class="space-y-1 flex-1">
        ${s.map(r=>l(r.id,r.icon,r.label)).join("")}
      </nav>
      ${a?`
      <div class="mt-auto pt-6 border-t ${o?"border-slate-800":"border-slate-200"} mb-6 px-4">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-full ${o?"bg-white/10 text-white":"bg-slate-100 border border-slate-200 text-slate-600"} shadow-sm flex items-center justify-center font-bold uppercase shrink-0">
            ${a.initials}
          </div>
          <div class="overflow-hidden">
            <p class="${o?"text-white":"text-slate-800"} text-sm font-semibold truncate">${a.name}</p>
            <p class="text-[10px] text-slate-400 font-medium">${a.subtitle}</p>
          </div>
        </div>
      </div>
      `:""}
      <button onclick="actions.logout()" class="flex items-center gap-3 px-4 py-3 rounded-xl ${o?"hover:bg-slate-800 text-slate-300":"hover:bg-slate-50 text-slate-500 hover:text-slate-900"} transition-all font-semibold">
        <i data-lucide="log-out"></i> Sair
      </button>
    </aside>
  `},De=({theme:e="light",sectionLabel:t,navItems:s,profile:a,drawerId:o})=>{if(!ye)return"";const l=e==="dark";return`
    <div class="fixed inset-0 z-50 flex md:hidden" id="${o}">
      <div class="fixed inset-0 bg-slate-900/40 backdrop-blur-sm shadow-sm" onclick="actions.toggleMobileMenu(false)"></div>
      <div class="relative flex flex-col w-72 max-w-[80vw] h-full ${l?"bg-slate-900 text-slate-300":"bg-white"} p-6 shadow-2xl transition-all duration-300 ease-in-out">
        <div class="flex items-center justify-between mb-8 px-2">
          <div class="flex items-center">${be(140,38)}</div>
          <button onclick="actions.toggleMobileMenu(false)" class="p-2 -mr-2 rounded-lg ${l?"text-slate-400 hover:text-white hover:bg-white/5":"text-slate-400 hover:text-slate-600 hover:bg-slate-50"}">
            <i data-lucide="x" class="w-5 h-5"></i>
          </button>
        </div>

        <p class="text-[10px] font-black ${l?"text-slate-500":"text-slate-400"} uppercase tracking-widest mb-4 px-2">${t}</p>
        <nav class="space-y-1.5 flex-1">
          ${s.map(r=>`
            <button onclick="actions.switchTabMobile('${r.id}')" class="w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-semibold ${v===r.id?l?"bg-white/10 text-white font-bold":"bg-blue-50 text-blue-700 font-bold":l?"text-slate-400 hover:bg-white/5 hover:text-white":"text-slate-500 hover:bg-slate-50"}">
              <i data-lucide="${r.icon}"></i> ${r.label}
            </button>
          `).join("")}
        </nav>

        <div class="mt-auto pt-6 border-t ${l?"border-slate-800":"border-slate-200"} px-2 flex flex-col gap-4">
          ${a?`
          <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-full ${l?"bg-white/10 text-white":"bg-slate-100 border border-slate-200 text-slate-600"} shadow-sm flex items-center justify-center font-bold uppercase shrink-0">
              ${a.initials}
            </div>
            <div class="overflow-hidden">
              <p class="${l?"text-white":"text-slate-800"} text-sm font-semibold truncate">${a.name}</p>
              <p class="text-[10px] text-slate-400 font-medium">${a.subtitle}</p>
            </div>
          </div>
          `:""}
          <button onclick="actions.logout()" class="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-rose-50 text-rose-600 transition-all font-semibold justify-center border border-rose-100 bg-rose-50/30">
            <i data-lucide="log-out"></i> Sair
          </button>
        </div>
      </div>
    </div>
  `},Ae=[{id:"overview",icon:"activity",label:"Visão geral"},{id:"dev_health",icon:"activity",label:"Saúde do sistema"},{id:"dev_diagnostics",icon:"search",label:"Diagnóstico"},{id:"dev_logs",icon:"file-text",label:"Logs de erros"},{id:"dev_audit",icon:"clipboard",label:"Auditoria"},{id:"dev_data",icon:"database",label:"Dados e backups"},{id:"escolas",icon:"building",label:"Escolas"},{id:"materias",icon:"book-open",label:"Matérias"},{id:"usuarios",icon:"users",label:"Usuários"}],Pe=[{id:"horarios",icon:"calendar",label:"Horários"},{id:"labs",icon:"test-tube",label:"Laboratórios"},{id:"materias",icon:"book-open",label:"Matérias"},{id:"usuarios",icon:"users",label:"Usuários"},{id:"relatorios",icon:"bar-chart",label:"Relatórios"}],bt=()=>`
  <div class="flex h-screen overflow-hidden print:overflow-visible flex-col md:flex-row">
    ${Ie({theme:"dark",sectionLabel:"Desenvolvedor",navItems:Ae})}
    ${De({theme:"dark",sectionLabel:"Desenvolvedor",navItems:Ae,drawerId:"dev-mobile-sidebar-drawer"})}

    <main class="flex-1 flex flex-col bg-slate-50 overflow-hidden print:bg-white print:overflow-visible">
      <header class="h-20 bg-white border-b border-slate-200 px-6 md:px-10 flex items-center justify-between shrink-0 print:hidden">
        <div class="flex items-center gap-3">
          <button onclick="actions.toggleMobileMenu(true)" class="md:hidden p-2 -ml-2 text-slate-600 hover:bg-slate-50 rounded-lg" id="btn-dev-toggle-menu">
            <i data-lucide="menu" class="w-6 h-6"></i>
          </button>
          <div class="min-w-0">
            <p class="text-[10px] font-black uppercase tracking-[0.18em] text-slate-400 truncate">Área do desenvolvedor</p>
            <h2 class="font-black text-base md:text-lg text-slate-900 truncate">Console Studia</h2>
          </div>
        </div>
        <div class="flex items-center gap-2">
          <span class="hidden md:inline-flex items-center gap-2 rounded-full bg-slate-900 text-white px-3 py-1.5 text-xs font-black uppercase tracking-[0.14em]"><i data-lucide="code-2" class="w-3.5 h-3.5"></i> Desenvolvedor</span>
        </div>
      </header>

      <div class="p-4 md:p-10 flex-1 overflow-y-auto space-y-6 md:space-y-8 print:p-0">
        ${v==="overview"?lt():""}
        ${v==="dev_health"?it():""}
        ${v==="dev_diagnostics"?nt():""}
        ${v==="dev_logs"?dt():""}
        ${v==="dev_audit"?ct():""}
        ${v==="dev_data"?pt():""}
        ${v==="escolas"?xt():""}
        ${v==="materias"?Ve({viewerRole:"dev"}):""}
        ${v==="usuarios"?We({viewerRole:"dev"}):""}
      </div>
    </main>

    ${qe()}
    ${Fe()}
    ${Ge()}
    ${rt()}
    ${He({viewerRole:"dev"})}
  </div>
`,ft=()=>`
  <div class="flex h-screen overflow-hidden print:overflow-visible flex-col md:flex-row">
    ${Ie({theme:"light",sectionLabel:"Direção Pedagógica",navItems:Pe})}
    ${De({theme:"light",sectionLabel:"Direção Pedagógica",navItems:Pe,drawerId:"diretor-mobile-sidebar-drawer"})}

    <main class="flex-1 flex flex-col bg-slate-50 overflow-hidden print:bg-white print:overflow-visible">
      <header class="h-20 bg-white border-b border-slate-200 px-6 md:px-10 flex items-center justify-between shrink-0 print:hidden">
        <div class="flex items-center gap-3">
          <button onclick="actions.toggleMobileMenu(true)" class="md:hidden p-2 -ml-2 text-slate-600 hover:bg-slate-50 rounded-lg" id="btn-diretor-toggle-menu">
            <i data-lucide="menu" class="w-6 h-6"></i>
          </button>
          <div class="min-w-0">
            <p class="text-[10px] font-black uppercase tracking-[0.18em] text-slate-400 truncate">Direção Pedagógica</p>
            <h2 class="font-black text-base md:text-lg text-slate-900 truncate">Console Studia</h2>
          </div>
        </div>
        <div class="flex gap-2">
          ${v==="horarios"?`
            <button onclick="actions.showSchoolPeriodsModal()" class="bg-slate-100 text-slate-700 px-3 md:px-4 py-2 md:py-2.5 rounded-lg font-bold shadow-sm flex items-center gap-1.5 text-xs md:text-sm hover:bg-slate-200 transition-all" id="btn-diretor-periods">
              <i data-lucide="clock-3" class="w-4 h-4"></i> <span>Períodos</span>
            </button>
            <button onclick="actions.showCreateModal()" class="bg-blue-600 text-white px-3 md:px-6 py-2 md:py-2.5 rounded-lg font-bold shadow-md flex items-center gap-1.5 md:gap-2 text-xs md:text-sm hover:bg-blue-700 transition-all" id="btn-diretor-new">
              <i data-lucide="plus" class="w-4 h-4 md:w-5 md:h-5"></i> <span>Novo Horário</span>
            </button>
          `:""}
          ${v==="labs"?`
            <button onclick="actions.showLabModal()" class="bg-slate-900 text-white px-3 md:px-6 py-2 md:py-2.5 rounded-lg font-bold shadow-md flex items-center gap-1.5 md:gap-2 text-xs md:text-sm hover:bg-slate-800 transition-all" id="btn-diretor-lab-new">
              <i data-lucide="plus" class="w-4 h-4 md:w-5 md:h-5"></i> <span>Reservar Lab</span>
            </button>
          `:""}
        </div>
      </header>

      <div class="p-4 md:p-10 flex-1 overflow-y-auto space-y-6 md:space-y-8 print:p-0">
        ${v==="horarios"?gt():""}
        ${v==="labs"?Qe():""}
        ${v==="materias"?Ve({viewerRole:"diretor"}):""}
        ${v==="usuarios"?We({viewerRole:"diretor"}):""}
        ${v==="relatorios"?wt():""}
      </div>
    </main>

    ${qe()}
    ${at()}
    ${Fe()}
    ${Ge()}
    ${He({viewerRole:"diretor"})}
  </div>
`,Q={dev:{badge:"bg-emerald-100 text-emerald-700",label:"Desenvolvedor"},diretor:{badge:"bg-amber-100 text-amber-700",label:"Diretor / Direção Pedagógica"},teacher:{badge:"bg-blue-100 text-blue-700",label:"Professor"}},ht=({viewerRole:e})=>{var o,l;const t=e==="dev",s=e==="diretor"?i==null?void 0:i.school_id:oe||(i==null?void 0:i.school_id)||((o=R[0])==null?void 0:o.id)||"",a=V.filter(r=>r.school_id===s);return`
    <section class="space-y-5 rounded-3xl border border-slate-200 bg-white p-5 md:p-7 shadow-sm">
      <div class="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
        <div>
          <h4 class="text-xl font-black text-slate-900">Matérias da escola</h4>
          <p class="mt-1 text-sm font-medium text-slate-500">Gerencie o catálogo de matérias desta escola.</p>
        </div>
        ${t?`
          <select onchange="actions.selectSubjectSchool(this.value)" class="w-full md:w-72 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm font-semibold text-slate-700" aria-label="Escola do catálogo de matérias">
            <option value="">Selecione uma escola</option>
            ${R.map(r=>`<option value="${r.id}" ${r.id===s?"selected":""}>${r.name}</option>`).join("")}
          </select>
        `:`<span class="rounded-full bg-blue-50 px-3 py-1.5 text-xs font-black uppercase text-blue-700">${((l=R.find(r=>r.id===s))==null?void 0:l.name)||"Minha escola"}</span>`}
      </div>

      <form onsubmit="actions.createSchoolSubject(event)" class="flex flex-col gap-3 sm:flex-row">
        <input id="school-subject-name" type="text" maxlength="255" placeholder="Adicionar matéria ao checklist" class="min-w-0 flex-1 rounded-xl border border-slate-200 bg-slate-50 px-4 py-2.5 text-sm font-medium text-slate-800" required ${s?"":"disabled"}>
        <button type="submit" class="rounded-xl bg-blue-600 px-5 py-2.5 text-sm font-bold text-white hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-50" ${s?"":"disabled"}>Adicionar matéria</button>
      </form>

      ${s?a.length===0?`
        <p class="rounded-xl bg-slate-50 p-4 text-sm font-semibold text-slate-500">O checklist está vazio. Adicione as matérias usadas nesta escola.</p>
      `:`
        <div class="space-y-3">
          ${a.map(r=>`
            <div class="rounded-2xl border border-slate-200 p-4">
              <div class="flex items-center justify-between gap-3">
                <h5 class="font-black text-slate-800">${r.subject}</h5>
                <button type="button" onclick="actions.deleteSchoolSubject(${r.id})" class="inline-flex items-center gap-2 rounded-lg border border-rose-200 bg-white px-3 py-2 text-xs font-bold text-rose-700 transition-colors hover:bg-rose-50 focus:outline-none focus:ring-2 focus:ring-rose-500" aria-label="Excluir matéria ${r.subject}" title="Excluir matéria">
                  <i data-lucide="trash-2" class="h-4 w-4"></i>
                  <span>Excluir</span>
                </button>
              </div>
            </div>
          `).join("")}
        </div>
      `:`
        <p class="rounded-xl bg-amber-50 p-4 text-sm font-semibold text-amber-800">Cadastre uma escola para gerenciar o catálogo de matérias.</p>
      `}
    </section>
  `},Ve=({viewerRole:e})=>`
  <div class="space-y-5">
    <div>
      <h3 class="text-2xl font-black text-slate-900">Matérias</h3>
      <p class="mt-1 text-sm font-medium text-slate-500">Gerencie o catálogo de matérias e as matérias disponíveis para os professores.</p>
    </div>
    ${ht({viewerRole:e})}
  </div>
`,We=({viewerRole:e="diretor"}={})=>{const t=e==="dev",s=[..._].filter(n=>t||n.role!=="dev").sort((n,m)=>(n.displayName||"").localeCompare(m.displayName||"")),a=s.find(n=>n.uid===ue&&n.role==="teacher"),o=a?V.filter(n=>n.school_id===a.school_id):[],l=s.filter(n=>n.uid!==(i==null?void 0:i.uid)).map(n=>n.uid),r=l.filter(n=>F.has(n)).length,d=l.length>0&&r===l.length,c=t?["teacher","diretor","dev"]:["teacher","diretor"];return`
    <div class="space-y-6">
      <div class="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
        <div>
          <h3 class="text-2xl font-black text-slate-900">Gestão de usuários</h3>
          <p class="text-sm text-slate-500 font-medium">${t?"Todas as contas cadastradas no sistema.":"Direção pedagógica e professores cadastrados na sua escola."}</p>
        </div>
        <div class="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
          ${t||e==="diretor"?`
            <button onclick="actions.showCreateUserModal('${e}')" class="bg-blue-600 hover:bg-blue-700 transition-all text-white px-5 py-2.5 rounded-lg font-bold flex items-center gap-2 text-sm shadow-md">
              <i data-lucide="plus" class="w-4 h-4"></i> Criar Usuário
            </button>
          `:""}
          <div class="inline-flex items-center gap-2 rounded-full bg-blue-50 text-blue-700 px-3 py-1.5 text-xs font-black uppercase tracking-[0.18em]">
            <i data-lucide="users" class="w-3.5 h-3.5"></i> ${s.length} usuários
          </div>
        </div>
      </div>

      ${r>0?`
        <div class="flex flex-col gap-3 rounded-2xl border border-rose-200 bg-rose-50 p-4 sm:flex-row sm:items-center sm:justify-between">
          <p class="text-sm font-bold text-rose-800">${r} conta${r===1?"":"s"} selecionada${r===1?"":"s"} para exclusão.</p>
          <button type="button" onclick="actions.deleteSelectedUsers()" class="inline-flex items-center justify-center gap-2 rounded-xl bg-rose-600 px-4 py-2.5 text-xs font-black text-white hover:bg-rose-700">
            <i data-lucide="trash-2" class="h-4 w-4"></i> Excluir selecionados
          </button>
        </div>
      `:""}

      <div class="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div class="overflow-x-auto">
          <table class="w-full min-w-[820px] text-left">
            <thead class="bg-slate-50 text-[10px] font-black uppercase tracking-[0.18em] text-slate-400 border-b border-slate-200">
              <tr>
                <th class="w-12 px-4 py-4">
                  <input type="checkbox" aria-label="Selecionar todos os usuários" ${d?"checked":""} ${l.length?"":"disabled"} onchange="actions.toggleAllUsers(this.checked)" class="rounded border-slate-300 text-blue-600 focus:ring-blue-500">
                </th>
                <th class="px-6 py-4">Nome</th>
                <th class="px-6 py-4">E-mail</th>
                <th class="px-6 py-4">Perfil</th>
                <th class="px-6 py-4">Matéria</th>
                <th class="px-6 py-4 text-right">Ações</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              ${s.length===0?`
                <tr>
                  <td colspan="6" class="px-6 py-10 text-center text-sm text-slate-500 font-medium">Nenhum usuário encontrado.</td>
                </tr>
              `:s.map(n=>`
                <tr class="hover:bg-slate-50 transition-colors">
                  <td class="px-4 py-6">
                    <input type="checkbox" aria-label="Selecionar ${n.email||n.displayName||"usuário"}" ${F.has(n.uid)?"checked":""} ${n.uid===(i==null?void 0:i.uid)?"disabled":""} onchange="actions.toggleUserSelection('${n.uid}', this.checked)" class="rounded border-slate-300 text-blue-600 focus:ring-blue-500 disabled:opacity-40">
                  </td>
                  <td class="px-6 py-4">
                    <div class="flex items-center gap-3">
                      <div class="w-10 h-10 rounded-full bg-slate-100 text-slate-700 font-black flex items-center justify-center uppercase">
                        ${(n.displayName||"U").slice(0,2)}
                      </div>
                      <div>
                        <div class="font-bold text-slate-900">${n.displayName||"Usuário sem nome"}</div>
                        <div class="text-[10px] uppercase tracking-[0.18em] text-slate-400">${n.uid===(i==null?void 0:i.uid)?"Você":"Conta ativa"}</div>
                      </div>
                    </div>
                  </td>
                  <td class="px-6 py-4 text-sm text-slate-600 font-medium">${n.email||"—"}</td>
                  <td class="px-6 py-4">
                    ${n.uid===(i==null?void 0:i.uid)?`
                      <span class="inline-flex items-center rounded-full px-2.5 py-1 text-[10px] font-black uppercase tracking-[0.16em] ${(Q[n.role]||Q.teacher).badge}">
                        ${(Q[n.role]||Q.teacher).label}
                      </span>
                    `:`
                      <select
                        onchange="actions.changeUserRole('${n.uid}', this.value)"
                        class="rounded-full border border-slate-200 px-2.5 py-1 text-[10px] font-black uppercase tracking-[0.16em] ${(Q[n.role]||Q.teacher).badge} cursor-pointer"
                      >
                        ${c.map(m=>`<option value="${m}" ${n.role===m?"selected":""}>${Q[m].label}</option>`).join("")}
                      </select>
                    `}
                  </td>
                  <td class="px-6 py-4 text-sm text-slate-600 font-medium">
                    ${n.role==="teacher"?`
                      <div class="flex min-w-40 flex-col items-start gap-2">
                        <span>${V.filter(m=>m.school_id===n.school_id&&(m.teacherIds||[]).includes(n.uid)).map(m=>m.subject).join(", ")||"—"}</span>
                        <button type="button" onclick="actions.toggleTeacherSubjectsEditor('${n.uid}')" class="inline-flex items-center gap-1.5 rounded-lg border border-blue-200 px-2.5 py-1.5 text-xs font-bold text-blue-700 hover:bg-blue-50">
                          <i data-lucide="pencil" class="h-3.5 w-3.5"></i> Editar matérias
                        </button>
                      </div>
                    `:"—"}
                  </td>
                  <td class="px-6 py-4 text-right">
                    <button
                      onclick="actions.deleteUser('${n.uid}', '${(n.displayName||"Usuário").replace(/'/g,"\\'")}', '${n.email||"usuário"}')"
                      class="inline-flex items-center gap-2 rounded-xl border ${n.uid===(i==null?void 0:i.uid)?"border-slate-200 text-slate-400 cursor-not-allowed":"border-rose-200 text-rose-600 hover:bg-rose-50"} px-3 py-2 text-xs font-bold disabled:opacity-60"
                      ${n.uid===(i==null?void 0:i.uid)?"disabled":""}
                    >
                      <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                      ${n.uid===(i==null?void 0:i.uid)?"Você":"Excluir"}
                    </button>
                  </td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      </div>
      ${a?`
        <div class="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/50 p-4" role="presentation">
          <section class="w-full max-w-lg overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl" role="dialog" aria-modal="true" aria-labelledby="teacher-subjects-title">
            <header class="flex items-start justify-between gap-4 border-b border-slate-200 p-5">
              <div>
                <h4 id="teacher-subjects-title" class="text-lg font-black text-slate-900">Matérias de ${a.displayName||a.email}</h4>
                <p class="mt-1 text-sm font-medium text-slate-500">Marque ou desmarque as matérias deste professor.</p>
              </div>
              <button type="button" onclick="actions.closeTeacherSubjectsEditor()" class="rounded-lg p-2 text-slate-500 hover:bg-slate-100" aria-label="Fechar edição de matérias">
                <i data-lucide="x" class="h-5 w-5"></i>
              </button>
            </header>
            <div class="max-h-[60vh] space-y-2 overflow-y-auto p-5">
              ${a.school_id?o.length?o.map(n=>`
                  <label class="flex cursor-pointer items-center gap-3 rounded-xl border border-slate-200 px-4 py-3 text-sm font-semibold text-slate-700 hover:bg-slate-50">
                    <input type="checkbox" ${(n.teacherIds||[]).includes(a.uid)?"checked":""} onchange="actions.setTeacherSubject('${n.id}', '${a.uid}', this.checked)" class="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500">
                    ${n.subject}
                  </label>
                `).join(""):`
                <p class="rounded-xl bg-slate-50 p-4 text-sm font-semibold text-slate-600">Não há matérias cadastradas para a escola deste professor.</p>
              `:`
                ${t?`
                  <div class="space-y-3 rounded-xl bg-amber-50 p-4">
                    <p class="text-sm font-semibold text-amber-800">Este professor ainda não está associado a uma escola. Selecione a escola para continuar.</p>
                    <select id="teacher-school-${a.uid}" class="w-full rounded-lg border border-amber-200 bg-white px-3 py-2 text-sm font-semibold text-slate-700">
                      <option value="">Selecione uma escola</option>
                      ${R.map(n=>`<option value="${n.id}">${n.name}</option>`).join("")}
                    </select>
                    <button type="button" onclick="actions.assignTeacherSchool('${a.uid}')" class="rounded-lg bg-blue-600 px-4 py-2 text-sm font-bold text-white hover:bg-blue-700">Associar escola</button>
                  </div>
                `:'<p class="rounded-xl bg-amber-50 p-4 text-sm font-semibold text-amber-800">Este professor ainda não está associado a uma escola. Peça à direção pedagógica para vinculá-lo.</p>'}
              `}
            </div>
            <footer class="flex justify-end border-t border-slate-200 p-4">
              <button type="button" onclick="actions.closeTeacherSubjectsEditor()" class="rounded-lg bg-slate-900 px-4 py-2 text-sm font-bold text-white hover:bg-slate-800">Concluir</button>
            </footer>
          </section>
        </div>
      `:""}
    </div>
  `},xt=()=>`
  <div class="space-y-6">
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
      <div>
        <h3 class="text-xl md:text-2xl font-black text-slate-900">Gerenciar Escolas</h3>
        <p class="text-xs md:text-sm text-slate-500 font-bold">Crie escolas e associe diretores</p>
      </div>
      <button onclick="actions.showCreateEscolaModal()" class="bg-blue-600 hover:bg-blue-700 transition-all text-white px-5 py-2.5 rounded-lg font-bold flex items-center gap-2 text-sm shadow-md">
        <i data-lucide="plus" class="w-4 h-4"></i> Nova Escola
      </button>
    </div>

    <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
      <div class="overflow-x-auto pr-2">
        <table class="w-full text-left min-w-[500px]">
          <thead class="bg-slate-50 text-[10px] font-black text-slate-400 uppercase border-b">
            <tr>
              <th class="px-8 py-5">Nome da Escola</th>
              <th class="px-8 py-5">Criado por</th>
              <th class="px-8 py-5">Data</th>
              <th class="px-8 py-5">Ações</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-slate-50">
            ${R&&R.length>0?R.map(e=>{var t;return`
              <tr class="hover:bg-slate-50 transition-all">
                <td class="px-8 py-5 font-bold">${e.name}</td>
                <td class="px-8 py-5 text-sm">
                  ${((t=_.find(s=>s.uid===e.createdBy))==null?void 0:t.displayName)||"—"}
                </td>
                <td class="px-8 py-5 text-sm text-slate-500">
                  ${new Date(e.createdAt).toLocaleDateString("pt-BR")}
                </td>
                <td class="px-8 py-5 text-right">
                  <button onclick="actions.deleteSchool('${e.id}')" class="text-slate-300 hover:text-rose-500 transition-all cursor-pointer" title="Deletar">
                    <i data-lucide="trash-2" class="w-4 h-4"></i>
                  </button>
                </td>
              </tr>
            `}).join(""):'<tr><td colspan="4" class="px-8 py-8 text-center text-slate-400 text-sm">Nenhuma escola criada ainda</td></tr>'}
          </tbody>
        </table>
      </div>
    </div>
  </div>
`,gt=()=>`
  <div class="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between print:mb-4">
    <h3 class="text-2xl font-black text-slate-900">Grade de Horários</h3>
    <div class="flex flex-wrap items-center gap-3 print:hidden">
      <label class="flex items-center gap-2 text-xs font-bold uppercase text-slate-500">
        Turno
        <select onchange="actions.setScheduleListTurno(this.value)" class="rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm font-semibold normal-case text-slate-700">
          <option value="todos" ${M==="todos"?"selected":""}>Todos</option>
          <option value="manha" ${M==="manha"?"selected":""}>Manhã</option>
          <option value="tarde" ${M==="tarde"?"selected":""}>Tarde</option>
          <option value="noite" ${M==="noite"?"selected":""}>Noite</option>
        </select>
      </label>
      <button onclick="actions.deleteAllSchedules()" class="inline-flex items-center gap-2 rounded-lg border border-rose-200 bg-white px-3 py-2 text-xs font-bold text-rose-700 transition-colors hover:bg-rose-50 disabled:cursor-not-allowed disabled:opacity-50" ${te($,M).length?"":"disabled"}>
        <i data-lucide="trash-2" class="h-4 w-4"></i>
        Remover ${M==="todos"?"todos":`do turno da ${Z[M]}`}
      </button>
    </div>
  </div>
  <div class="bg-white rounded-3xl border overflow-hidden shadow-sm print:border-none print:shadow-none">
    <div class="overflow-x-auto pr-2">
      <table class="w-full text-left min-w-[800px]">
      <thead class="bg-slate-50 text-[10px] font-black text-slate-400 uppercase border-b">
        <tr>
          <th class="px-8 py-5">Matéria</th>
          <th class="px-8 py-5">Turno</th>
          <th class="px-8 py-5">Horário / Data</th>
          <th class="px-8 py-5">Professor</th>
          <th class="px-8 py-5 text-center">Status</th>
          <th class="px-8 py-5 print:hidden"></th>
        </tr>
      </thead>
      <tbody class="divide-y divide-slate-50">
        ${te($,M).map(e=>`
          <tr class="hover:bg-slate-50 transition-all">
            <td class="px-8 py-5 font-bold">${e.subject}</td>
            <td class="px-8 py-5 text-xs font-black uppercase text-slate-500">${Z[Te(e)]}</td>
            <td class="px-8 py-5">
              <div class="text-sm font-bold">${e.startTime}</div>
              <div class="text-[10px] text-slate-400 uppercase font-bold">${e.date}</div>
            </td>
            <td class="px-8 py-5 text-sm">
              <span class="font-bold text-slate-800">${e.teacherName}</span>
              ${e.classGroup?`<span class="block text-xs font-semibold text-blue-600 mt-0.5">${e.classGroup}</span>`:""}
            </td>
            <td class="px-8 py-5">
              <div class="flex justify-center">
                <span class="text-[10px] font-black uppercase px-3 py-1 rounded-full ${e.status==="confirmed"?"bg-blue-100 text-blue-700":e.status==="absent"?"bg-rose-100 text-rose-700":"bg-slate-100 text-slate-500"}">${e.status==="confirmed"?"Confirmado":e.status==="absent"?"Ausente":"Pendente"}</span>
              </div>
            </td>
            <td class="px-8 py-5 text-right print:hidden">
              <div class="flex items-center justify-end gap-3">
                <button type="button" onclick="actions.showEditModalById(${e.id})" class="inline-flex h-9 items-center justify-center gap-2 rounded-lg bg-blue-50 px-3 text-xs font-bold text-blue-700 transition-colors hover:bg-blue-100 focus:outline-none focus:ring-2 focus:ring-blue-500" title="Editar horário">
                  <i data-lucide="pencil" class="w-4 h-4"></i>
                  <span>Editar</span>
                </button>
                <button onclick="actions.showDeleteModal(${e.id})" class="inline-flex h-9 w-9 items-center justify-center rounded-lg bg-rose-50 text-rose-700 transition-colors hover:bg-rose-100 focus:outline-none focus:ring-2 focus:ring-rose-500" title="Excluir horário" aria-label="Excluir horário">
                  <i data-lucide="trash-2" class="w-4 h-4"></i>
                </button>
              </div>
            </td>
          </tr>
        `).join("")}
      </tbody>
    </table>
   </div>
  </div>
`,vt=()=>`
  <div class="space-y-8 animate-fade-in">
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
      <div>
        <h3 class="text-xl md:text-2xl font-black text-slate-900">Minhas Matérias</h3>
        <p class="text-xs md:text-sm text-slate-500 font-bold">Gerencie as matérias que você leciona.</p>
      </div>
      <button onclick="actions.showAddMatériaModal()" class="bg-blue-600 hover:bg-blue-700 transition-all text-white px-5 py-2.5 rounded-lg font-bold flex items-center gap-2 text-sm shadow-md">
        <i data-lucide="plus" class="w-4 h-4"></i> Adicionar Matéria
      </button>
    </div>

    <div class="space-y-5">
      <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
        <h4 class="text-sm font-black uppercase tracking-[0.18em] text-slate-400 mb-4">Editar minhas matérias</h4>
        ${(()=>{const e=(V||[]).filter(s=>s.school_id===(i==null?void 0:i.school_id)),t=new Set((window.teacherSubjects||[]).map(s=>s.subject));return e.length?`
            <div class="flex flex-wrap gap-2">
              ${e.map(s=>{const a=t.has(s.subject);return`
                  <label class="inline-flex items-center gap-2 rounded-full border px-3 py-2 text-xs font-bold ${a?"border-blue-200 bg-blue-50 text-blue-800":"border-slate-200 bg-slate-50 text-slate-600"}">
                    <input type="checkbox" ${a?"checked":""} onchange="actions.setTeacherSubject('${s.id}', '${i.uid}', this.checked)" class="rounded border-slate-300 text-blue-600 focus:ring-blue-500">
                    ${s.subject}
                  </label>
                `}).join("")}
            </div>
          `:'<p class="text-sm font-medium text-slate-500">Ainda não há matérias cadastradas para a sua escola.</p>'})()}
      </div>

      <div class="grid gap-4">
        ${(()=>{const e=window.teacherSubjects||[];return e.length===0?`
              <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-12 text-center">
                <i data-lucide="book" class="w-12 h-12 text-slate-300 mx-auto mb-4"></i>
                <p class="text-slate-400 font-bold">Você ainda não adicionou nenhuma matéria.</p>
              </div>
            `:e.map(t=>`
            <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-6 flex items-center justify-between hover:shadow-md transition-all">
              <div class="flex items-center gap-4">
                <div class="w-12 h-12 rounded-lg bg-blue-50 flex items-center justify-center">
                  <i data-lucide="book-open" class="w-6 h-6 text-blue-600"></i>
                </div>
                <div>
                  <h4 class="font-bold text-slate-900">${t.subject}</h4>
                  <p class="text-xs text-slate-400">Matéria</p>
                </div>
              </div>
              <button onclick="actions.deleteMatéria('${t.subject}')" class="text-rose-600 hover:bg-rose-50 p-2 rounded-lg transition-all">
                <i data-lucide="trash-2" class="w-5 h-5"></i>
              </button>
            </div>
          `).join("")})()}
      </div>
    </div>
  </div>
`,Qe=()=>{const e=[...U].sort((r,d)=>r.date.localeCompare(d.date)||r.startTime.localeCompare(d.startTime)),t=e.filter(r=>(!A.date||r.date===A.date)&&(A.labId==="all"||r.labId===A.labId)&&r.teacherName.toLocaleLowerCase().includes(A.teacher.toLocaleLowerCase())),s=new Date,a=`${s.getFullYear()}-${String(s.getMonth()+1).padStart(2,"0")}-${String(s.getDate()).padStart(2,"0")}`,o=r=>{const[d,c,n]=r.split("-");return`${n}/${c}/${d}`},l=e.filter(r=>r.date>=a);return`
    <div class="space-y-6">
      <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h3 class="text-xl md:text-2xl font-black text-slate-900">Agenda dos Laboratórios</h3>
          <p class="text-xs md:text-sm text-slate-500 font-medium">Consulte as reservas da escola, filtre a agenda e escolha um horário livre.</p>
        </div>
        <button onclick="actions.showLabModal()" class="bg-blue-600 hover:bg-blue-700 transition-all text-white px-5 py-2.5 rounded-lg font-bold flex items-center gap-2 text-sm shadow-md">
          <i data-lucide="plus" class="w-4 h-4"></i> Nova reserva
        </button>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        ${["info","chem"].map(r=>{const d=l.filter(c=>c.labId===r).slice(0,3);return`
            <section class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
              <h4 class="font-black text-slate-800 flex items-center gap-2">
                <i data-lucide="${r==="info"?"monitor":"beaker"}" class="w-5 h-5 text-blue-600"></i>
                ${r==="info"?"Informática":"Química"}
              </h4>
              <div class="mt-4 space-y-2">
                ${d.map(c=>`
                  <div class="flex justify-between gap-3 rounded-xl bg-slate-50 p-3">
                    <span class="min-w-0 truncate text-sm font-semibold text-slate-700">${c.teacherName}</span>
                    <span class="shrink-0 text-xs font-bold text-slate-500">${o(c.date)} · ${c.startTime.slice(0,5)}–${c.endTime.slice(0,5)}</span>
                  </div>
                `).join("")||'<p class="py-3 text-sm text-slate-400">Sem reservas futuras.</p>'}
              </div>
            </section>
          `}).join("")}
      </div>

      <section class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
        <div class="border-b border-slate-100 p-5">
          <div class="flex flex-col gap-1 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <h4 class="font-black text-slate-900">Reservas da escola</h4>
              <p class="text-sm text-slate-500">${t.length} de ${U.length} reservas</p>
            </div>
            <div class="grid grid-cols-1 gap-3 pt-3 sm:grid-cols-3 sm:pt-0">
              <label class="text-xs font-bold text-slate-500">
                Data
                <input type="date" value="${A.date}" onchange="actions.setLabFilter('date', this.value)" class="mt-1 block w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700">
              </label>
              <label class="text-xs font-bold text-slate-500">
                Laboratório
                <select onchange="actions.setLabFilter('labId', this.value)" class="mt-1 block w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700">
                  <option value="all" ${A.labId==="all"?"selected":""}>Todos</option>
                  <option value="info" ${A.labId==="info"?"selected":""}>Informática</option>
                  <option value="chem" ${A.labId==="chem"?"selected":""}>Química</option>
                </select>
              </label>
              <label class="text-xs font-bold text-slate-500">
                Professor
                <input type="search" value="${A.teacher}" onchange="actions.setLabFilter('teacher', this.value)" placeholder="Buscar nome" class="mt-1 block w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700">
              </label>
            </div>
          </div>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full min-w-[650px] text-left">
            <thead class="bg-slate-50 text-[10px] font-black uppercase text-slate-400">
              <tr>
                <th class="px-5 py-4">Data</th>
                <th class="px-5 py-4">Horário</th>
                <th class="px-5 py-4">Laboratório</th>
                <th class="px-5 py-4">Responsável</th>
                <th class="px-5 py-4 text-center">Ação</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              ${t.map(r=>`
                <tr class="hover:bg-slate-50">
                  <td class="px-5 py-4 font-semibold text-slate-700">${o(r.date)}</td>
                  <td class="px-5 py-4 font-mono text-sm text-slate-600">${r.startTime.slice(0,5)}–${r.endTime.slice(0,5)}</td>
                  <td class="px-5 py-4 text-sm font-semibold text-slate-700">${r.labId==="info"?"Informática":"Química"}</td>
                  <td class="px-5 py-4 text-sm font-semibold text-slate-700">${r.teacherName}</td>
                  <td class="px-5 py-4 text-center">
                    ${i.role==="dev"||i.role==="diretor"||r.teacherId===i.uid?`
                      <button onclick="actions.deleteLabBooking('${r.id}')" class="inline-flex h-9 w-9 items-center justify-center rounded-lg bg-rose-50 text-rose-700 transition-colors hover:bg-rose-100 focus:outline-none focus:ring-2 focus:ring-rose-500" title="Cancelar reserva" aria-label="Cancelar reserva">
                        <i data-lucide="trash-2" class="h-4 w-4"></i>
                      </button>
                    `:'<span class="text-slate-300">-</span>'}
                  </td>
                </tr>
              `).join("")||`
                <tr><td colspan="5" class="px-5 py-10 text-center text-sm font-medium text-slate-400">
                  ${U.length?"Nenhuma reserva corresponde aos filtros.":"Ainda não há reservas para esta escola."}
                </td></tr>
              `}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  `},wt=()=>{const e=Ye();let t=$;P!=="all"&&(t=$.filter(r=>{try{return Ce(r.date)===P}catch{return!1}})),t=te(t,B);const s=je(t);let a=O;if(J!=="all"&&(a=O.filter(r=>r.uid===J)),a.length===0&&t.length>0){const r=new Set,d=[];t.forEach(c=>{c.teacherId&&!r.has(c.teacherId)&&(r.add(c.teacherId),d.push({uid:c.teacherId,displayName:c.teacherName,subject:c.subject}))}),a=d}let o="grid grid-cols-1 sm:grid-cols-2 gap-3.5 print:grid-cols-2 print:gap-3 justify-center";w==="small"?o="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-2 print:grid-cols-5 print:gap-1 justify-center":w==="medium"?o="grid grid-cols-1 sm:grid-cols-2 gap-3.5 print:grid-cols-2 print:gap-3 justify-center":w==="large"?o="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 gap-5 print:grid-cols-3 print:gap-3 justify-center":w==="esticado"?o="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-2 gap-6 print:grid-cols-2 print:gap-4 justify-center":w==="super_esticado"&&(o="grid grid-cols-1 gap-8 print:grid-cols-1 print:gap-6 justify-center");const l=`
    <div class="flex gap-2 bg-slate-100 p-1.5 rounded-2xl w-full sm:w-fit mb-8 print:hidden overflow-x-auto scrollbar-none select-none shrink-0">
      <button onclick="actions.setRelatorioSubTab('urania')" class="px-5 py-2.5 rounded-lg font-bold text-sm transition-all flex items-center gap-2 whitespace-nowrap ${me==="urania"?"bg-white text-blue-600 shadow-sm":"text-slate-500 hover:text-slate-800"}">
        <i data-lucide="grid-3x3" class="w-4 h-4 text-slate-500"></i> Grade de Professores (Individual)
      </button>
      <button onclick="actions.setRelatorioSubTab('frequent')" class="px-5 py-2.5 rounded-lg font-bold text-sm transition-all flex items-center gap-2 whitespace-nowrap ${me==="frequent"?"bg-white text-blue-600 shadow-sm":"text-slate-500 hover:text-slate-800"}">
        <i data-lucide="bar-chart-3" class="w-4 h-4 text-slate-500"></i> Gráfico de Frequência
      </button>
    </div>
  `;return me==="frequent"?`
      <div class="space-y-4">
        <h3 class="text-2xl font-black text-slate-900 print:hidden">Relatório de Frequência</h3>
        ${l}
        <div class="bg-white p-10 rounded-[2.5rem] border shadow-sm flex flex-col items-center">
          <div class="flex items-end gap-6 h-64 mb-10">
            <div class="w-20 bg-blue-500 rounded-t-2xl" style="height: ${E.total>0?E.confirmed/E.total*100:0}%"></div>
            <div class="w-20 bg-rose-500 rounded-t-2xl" style="height: ${E.total>0?E.absent/E.total*100:0}%"></div>
            <div class="w-20 bg-amber-400 rounded-t-2xl" style="height: ${E.total>0?E.pending/E.total*100:0}%"></div>
          </div>
          <div class="grid grid-cols-3 gap-10 text-center uppercase font-black text-xs">
            <div class="text-blue-600">Presentes: ${E.confirmed}</div>
            <div class="text-rose-500">Ausentes: ${E.absent}</div>
            <div class="text-amber-500">Pendentes: ${E.pending}</div>
          </div>
        </div>
      </div>
    `:`
    <div class="space-y-6">
      <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 print:hidden">
        <div>
          <h3 class="text-2xl font-black text-slate-900">Grades Escolares</h3>
          <p class="text-xs text-slate-400 mt-1">Baixe a grade escolar em PDF ou visualize instantaneamente para impressão.</p>
        </div>
        <div class="flex flex-wrap items-center gap-3">
          <!-- Button 1: Download Direct PDF with html2pdf -->
          <button id="btn-download-pdf" onclick="actions.downloadPDF()" class="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-lg font-bold shadow-md flex items-center gap-2 transition-all">
            <i data-lucide="download"></i> Baixar Arquivo PDF
          </button>
        </div>
      </div>

      ${l}

      <!-- Modelo Selector Tab -->
      <div class="flex gap-2 bg-slate-100 p-1.5 rounded-2xl w-full sm:w-fit mb-2 print:hidden overflow-x-auto scrollbar-none select-none shrink-0" id="report-model-tabs">
        <button onclick="actions.setReportModel('prof_turma')" class="px-4 py-2 rounded-xl font-bold text-xs transition-all flex items-center gap-2 whitespace-nowrap ${H==="prof_turma"?"bg-white text-[#2E5077] shadow-sm":"text-slate-500 hover:text-slate-800"}">
          <i data-lucide="user" class="w-3.5 h-3.5 text-slate-500"></i> Professor (por Turma)
        </button>
        <button onclick="actions.setReportModel('prof_subject')" class="px-4 py-2 rounded-xl font-bold text-xs transition-all flex items-center gap-2 whitespace-nowrap ${H==="prof_subject"?"bg-white text-[#2E5077] shadow-sm":"text-slate-500 hover:text-slate-800"}">
          <i data-lucide="book" class="w-3.5 h-3.5 text-slate-500"></i> Professor (por Matéria)
        </button>
        <button onclick="actions.setReportModel('turma_grid')" class="px-4 py-2 rounded-xl font-bold text-xs transition-all flex items-center gap-2 whitespace-nowrap ${H==="turma_grid"?"bg-white text-[#2E5077] shadow-sm":"text-slate-500 hover:text-slate-800"}">
          <i data-lucide="users" class="w-3.5 h-3.5 text-slate-500"></i> Todas as Turmas
        </button>
      </div>

      <!-- Control Box -->
      <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4 print:hidden">
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          <div class="space-y-2">
            <label class="text-[10px] font-black text-slate-400 uppercase tracking-wider">Nome do Colégio</label>
            <input type="text" value="${le}" oninput="actions.setSchoolName(this.value)" class="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent">
          </div>

          <div class="space-y-2">
            <label class="text-[10px] font-black text-slate-400 uppercase tracking-wider">Selecione a Semana</label>
            <select onchange="actions.setReportWeek(this.value)" class="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent">
              <option value="all" ${P==="all"?"selected":""}>Todas as semanas (Geral Acumulada)</option>
              ${e.map(r=>`<option value="${r}" ${P===r?"selected":""}>${$e(r)}</option>`).join("")}
            </select>
          </div>

          <div class="space-y-2">
            <label class="text-[10px] font-black text-slate-400 uppercase tracking-wider">Turno</label>
            <select onchange="actions.setReportTurno(this.value)" class="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent">
              <option value="todos" ${B==="todos"?"selected":""}>Todos</option>
              <option value="manha" ${B==="manha"?"selected":""}>Manhã</option>
              <option value="tarde" ${B==="tarde"?"selected":""}>Tarde</option>
              <option value="noite" ${B==="noite"?"selected":""}>Noite</option>
            </select>
          </div>

          <div class="space-y-2">
            <label class="text-[10px] font-black text-slate-400 uppercase tracking-wider">Filtro de Professor</label>
            <select onchange="actions.setReportTeacher(this.value)" class="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent">
              <option value="all" ${J==="all"?"selected":""}>Todos os professores (${a.length})</option>
              ${O.map(r=>`<option value="${r.uid}" ${J===r.uid?"selected":""}>${r.displayName}</option>`).join("")}
            </select>
          </div>

          <div class="space-y-2">
            <label class="text-[10px] font-black text-slate-400 uppercase tracking-wider">Tamanho dos Cards</label>
            <select onchange="actions.setReportCardSize(this.value)" class="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent">
              <option value="small" ${w==="small"?"selected":""}>Pequeno (Compacto)</option>
              <option value="medium" ${w==="medium"?"selected":""}>Médio (Recomendado)</option>
              <option value="large" ${w==="large"?"selected":""}>Grande (Mais Legível)</option>
              <option value="esticado" ${w==="esticado"?"selected":""}>Esticado (Largo - 2 por linha)</option>
              <option value="super_esticado" ${w==="super_esticado"?"selected":""}>Super Esticado (Página Inteira - 1 por linha)</option>
            </select>
          </div>
        </div>
      </div>

      <!-- Live Printable Preview (Mimicking A4 Sheet) -->
      <div class="w-full overflow-x-auto pb-4 scrollbar-none">
        <div class="printable-sheet bg-white border border-slate-200 rounded-[2rem] p-6 md:p-12 shadow-xl relative overflow-hidden min-w-[750px] md:min-w-0">
        <!-- Sheet Header -->
        <div class="flex flex-col md:flex-row justify-between items-center border-b border-blue-100 pb-6 mb-8 gap-4">
          <div class="flex items-center gap-4">
            <!-- Studia Logo matching user image with book and orbital swoosh -->
            <svg width="240" height="65" viewBox="0 0 240 65" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: block;">
              <!-- Light Blue Ribbon/Swoosh flourishes around the text -->
              <path d="M10 24C45 6, 85 45, 128 35C155 28, 175 14, 235 22" stroke="#7ec2f2" stroke-width="2.8" stroke-linecap="round" fill="none" opacity="0.8"/>
              <path d="M124 35C136 43, 155 35, 150 24C145 15, 132 18, 126 27" stroke="#3b82f6" stroke-width="2" stroke-linecap="round" fill="none" opacity="0.9"/>
              
              <!-- Subtle glow on the outer swoosh -->
              <path d="M175 14C195 6, 215 16, 235 22" stroke="#7ec2f2" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round" fill="none" opacity="0.3"/>

              <!-- Open Book icon centered above "Stu" -->
              <g transform="translate(68, 2)">
                <!-- Left half -->
                <path d="M15 14C15 6, 25 3, 30 7.5L30 23C25 18, 15 19, 15 22Z" fill="#5B99C2" />
                <!-- Right half -->
                <path d="M45 14C45 6, 35 3, 30 7.5L30 23C35 18, 45 19, 45 22Z" fill="#2E5077" />
                <path d="M18 16C18 13, 24 10, 27 12L27 21" stroke="white" stroke-width="0.8" opacity="0.4" fill="none"/>
                <path d="M42 16C42 13, 36 10, 33 12L33 21" stroke="white" stroke-width="0.8" opacity="0.4" fill="none"/>
              </g>

              <!-- Main Title: Studia -->
              <text x="18" y="47" font-family="'Inter', sans-serif" font-weight="800" font-size="34" fill="#2E5077" letter-spacing="-1.5">Studia</text>
              <!-- Subtitle: GRADE ESCOLAR DIGITAL -->
              <text x="21" y="58" font-family="'Inter', sans-serif" font-weight="700" font-size="8.5" fill="#5B99C2" letter-spacing="1.2">GRADE ESCOLAR DIGITAL</text>
            </svg>
          </div>
          
          <div class="text-center md:text-right">
            <h4 class="text-sm font-black text-slate-800 uppercase tracking-wide">${le}</h4>
            <p class="text-[10px] text-slate-400 font-extrabold uppercase tracking-widest mt-1">
              ${H==="turma_grid"?"Relatório de Turmas (Individual)":"Relatório de Professores (Individual)"} - ${P==="all"?"Grade Geral Acumulada":$e(P)} - ${B==="todos"?"Todos os turnos":Z[B]}
            </p>
          </div>
        </div>

        ${H==="turma_grid"?`
          <!-- Turmas Cards Grid -->
          ${(()=>{const d=[...new Set(t.filter(c=>c.classGroup&&c.classGroup.trim()!=="").map(c=>c.classGroup))].sort();return d.length===0?`
                <div class="text-center py-20 text-slate-400 font-bold space-y-2 col-span-full">
                  <i data-lucide="info" class="w-12 h-12 mx-auto text-slate-300 col-span-full"></i>
                  <p>Nenhuma turma encontrada nos horários selecionados. Confira a semana ou cadastre aulas para a escola.</p>
                </div>
              `:`
              <div class="${o}">
                ${d.map(c=>{const n=t.filter(m=>m.classGroup===c);return Oe(c,n,s)}).join("")}
              </div>
            `})()}
        `:`
          <!-- Teachers Cards Grid -->
          ${a.length===0?`
            <div class="text-center py-20 text-slate-400 font-bold space-y-2 col-span-full">
              <i data-lucide="info" class="w-12 h-12 mx-auto text-slate-300"></i>
              <p>Nenhum horário cadastrado para exibição na grade individual</p>
            </div>
          `:`
            <div class="${o}">
              ${a.map(r=>{const d=t.filter(c=>c.teacherId===r.uid);return Me(r,d,s,H)}).join("")}
            </div>
          `}
        `}

        <div class="border-t border-slate-100 mt-12 pt-4 flex justify-end text-[8px] text-slate-400 font-extrabold uppercase tracking-widest leading-none">
          <span>Data de emissão: ${new Date().toLocaleDateString("pt-BR")}</span>
        </div>
        </div>
      </div>
    </div>
  `};let ce=0;const yt=[{title:"Studia",subtitle:"Organização da rotina escolar",content:"Uma plataforma para consultar horários, organizar laboratórios e acompanhar informações da escola.",icon:"book-open"},{title:"Organização",subtitle:"Informações em um só lugar",content:"Horários difíceis de consultar e reservas de espaços sem uma agenda compartilhada.",icon:"alert-circle"},{title:"Acesso simples",subtitle:"Cada perfil com suas ferramentas",content:"Professores consultam seus horários e a direção organiza as informações da escola.",icon:"check-circle"},{title:"Funcionalidades",subtitle:"O que o Studia faz?",content:`• Grades por professor e turma
• Reservas de laboratórios
• Relatórios para consulta e impressão`,icon:"layers"},{title:"Tecnologia",subtitle:"Stack Robusta",content:"Backend robusto para persistência sólida e Frontend moderno com Tailwind CSS.",icon:"cpu"}],pe={dev:["overview","dev_health","dev_diagnostics","dev_logs","dev_audit","dev_data","escolas","materias","usuarios"],diretor:["horarios","labs","materias","usuarios","relatorios"],teacher:["horarios","labs","materias"]},Je={toggleMobileMenu(e){ye=e;const t=p("#mobile-drawer");t&&t.classList.toggle("hidden",!e)},setScheduleTurno(e){const t=p("#form-period-options");t&&(t.innerHTML=Ue(e))},setPeriodAdminTurno(e){ee=e},setScheduleListTurno(e){M=e,this.renderCurrentView()},setTeacherTurno(e){K=e,this.renderCurrentView()},switchTabMobile(e){var t;(t=pe[i==null?void 0:i.role])!=null&&t.includes(e)&&(v=e,ye=!1,this.init())},setReportTurno(e){B=e,this.renderCurrentView()},renderCurrentView(){try{i&&!i.accessToken&&(localStorage.removeItem("user"),i=null),i?i.role==="dev"?W(bt()):i.role==="diretor"?W(ft()):W(xe()):W(ke()),typeof lucide<"u"&&lucide.createIcons()}catch(e){console.error("Render error:",e)}},async init(){var e,t;try{i?((e=pe[i.role])!=null&&e.includes(v)||(v=((t=pe[i.role])==null?void 0:t[0])||"horarios"),await this.refreshData(),i.role==="dev"&&await this.loadDeveloperPanel(v),this.renderCurrentView()):W(ke()),typeof lucide<"u"&&lucide.createIcons()}catch(s){console.error("Init error:",s)}},showLoginModal(e="login"){D=e,this.init()},hideLoginModal(){D="closed",this.init()},toggleAuthMode(e){D=e,this.init()},submitContact(e){var o,l,r;e.preventDefault();const t=(o=document.getElementById("landing-name"))==null?void 0:o.value,s=(l=document.getElementById("landing-contact"))==null?void 0:l.value,a=(r=document.getElementById("landing-message"))==null?void 0:r.value;t&&s&&a&&(u(`Obrigado ${t}! Recebemos sua mensagem. Entraremos em contato em breve!`),e.target.reset())},showCreateModal(){var t,s;const e=p("#create-modal");e&&(e.classList.remove("hidden"),this.setScheduleCreateMode(((t=p("#form-schedule-mode"))==null?void 0:t.value)||"weekly"),this.updateScheduleSubjectOptions(((s=p("#form-teacher"))==null?void 0:s.value)||""),typeof lucide<"u"&&lucide.createIcons())},setScheduleCreateMode(e){var l,r;const t=e==="weekly";(l=p("#form-weekly-fields"))==null||l.classList.toggle("hidden",!t),(r=p("#form-single-date-field"))==null||r.classList.toggle("hidden",t);const s=p("#form-start-date"),a=p("#form-end-date"),o=p("#form-date");s&&(s.required=t),a&&(a.required=t),o&&(o.required=!t)},hideCreateModal(){const e=p("#create-modal");e&&e.classList.add("hidden")},showSchoolPeriodsModal(){var e;(i==null?void 0:i.role)==="diretor"&&((e=p("#school-periods-modal"))==null||e.classList.remove("hidden"))},hideSchoolPeriodsModal(){var e;(e=p("#school-periods-modal"))==null||e.classList.add("hidden")},async saveSchoolPeriod(e){var l,r,d,c,n;e.preventDefault();const t=((l=p("#period-turno"))==null?void 0:l.value)||ee;ee=t;const s=t==="noite"?5:6,a=new Set(G.filter(m=>m.turno===t).map(m=>Number(m.periodNumber)));let o=1;for(;a.has(o)&&o<=s;)o+=1;if(o>s)return u(`O turno da ${Z[t].toLowerCase()} já possui o limite de ${s} aulas.`);try{await f.post("/api/school-periods",{periodNumber:o,turno:t,name:(d=(r=p("#period-name"))==null?void 0:r.value)==null?void 0:d.trim(),startTime:(c=p("#period-start"))==null?void 0:c.value,endTime:(n=p("#period-end"))==null?void 0:n.value}),await this.refreshData(),this.renderCurrentView(),this.showSchoolPeriodsModal()}catch(m){u(m.message||"Não foi possível salvar o período.")}},async updateSchoolPeriod(e,t){var s,a,o,l,r;e.preventDefault();try{await f.patch(`/api/school-periods/${t}`,{turno:(s=G.find(d=>d.id===t))==null?void 0:s.turno,name:(o=(a=p(`#period-name-${t}`))==null?void 0:a.value)==null?void 0:o.trim(),startTime:(l=p(`#period-start-${t}`))==null?void 0:l.value,endTime:(r=p(`#period-end-${t}`))==null?void 0:r.value}),await this.refreshData(),this.renderCurrentView(),this.showSchoolPeriodsModal()}catch(d){u(d.message||"Não foi possível atualizar o período.")}},async deleteSchoolPeriod(e){const t=G.find(a=>a.id===e);if(await u(`Excluir o período "${(t==null?void 0:t.name)||""}"? Os horários já cadastrados não serão alterados.`,{confirm:!0,title:"Excluir período"}))try{await f.delete(`/api/school-periods/${e}`),await this.refreshData(),this.renderCurrentView(),this.showSchoolPeriodsModal()}catch(a){u(a.message||"Não foi possível excluir o período.")}},showEditModalById(e){const t=$.find(a=>String(a.id)===String(e));if(!t){u("Não foi possível localizar este horário. Atualize a página e tente novamente.");return}const s=p("#edit-modal");if(!s){u("O formulário de edição não está disponível nesta tela.");return}p("#edit-form-id").value=t.id||"",p("#edit-form-subject").value=t.subject||"",p("#edit-form-class-group").value=t.classGroup||"",p("#edit-form-date").value=t.date||"",p("#edit-form-room").value=t.room||"",p("#edit-form-turno").value=Te(t),p("#edit-form-start").value=t.startTime?String(t.startTime).slice(0,5):"",p("#edit-form-end").value=t.endTime?String(t.endTime).slice(0,5):"",p("#edit-form-teacher").value=t.teacherId||"",p("#edit-form-status").value=t.status||"pending",this.updateScheduleSubjectOptions(t.teacherId||"",t.subject||"","edit-form"),s.classList.remove("hidden"),typeof lucide<"u"&&lucide.createIcons()},hideEditModal(){const e=p("#edit-modal");e&&e.classList.add("hidden")},showDeleteModal(e){const t=p("#delete-modal");t&&(p("#delete-schedule-id").value=e,t.classList.remove("hidden"),typeof lucide<"u"&&lucide.createIcons())},hideDeleteModal(){const e=p("#delete-modal");e&&e.classList.add("hidden")},updateScheduleSubjectOptions(e,t="",s="form"){const a=p(`#${s}-subject`),o=p(`#${s}-subject-options`);if(!a||!o)return;const l=st(e);o.innerHTML=l.map(r=>`<option value="${r}"></option>`).join(""),a.value=t||""},async confirmDeleteSchedule(){const e=p("#delete-schedule-id").value;try{await f.delete(`/api/schedules/${e}`),this.hideDeleteModal(),this.init()}catch{u("Erro ao excluir.")}},showLabModal(){document.body.insertAdjacentHTML("beforeend",ot());const e=p("#lab-modal");if(e){e.classList.remove("hidden");const t=new Date,s=`${t.getFullYear()}-${String(t.getMonth()+1).padStart(2,"0")}-${String(t.getDate()).padStart(2,"0")}`,a=p("#lab-date");a&&(a.min=s,a.value=s),typeof lucide<"u"&&lucide.createIcons()}},hideLabModal(){const e=p("#lab-modal");e&&e.remove()},switchTab(e){var t;(t=pe[i==null?void 0:i.role])!=null&&t.includes(e)&&(v=e,this.init())},async loadDeveloperPanel(e=v){try{["overview","dev_health","dev_diagnostics","dev_data"].includes(e)?(T=await f.get("/api/dev/diagnostics"),delete X.diagnostics):e==="dev_logs"?(ve=await f.get("/api/dev/logs"),delete X.logs):e==="dev_audit"&&(ge=await f.get("/api/dev/audit"),delete X.audit)}catch(t){const s=["overview","dev_health","dev_diagnostics","dev_data"].includes(e)?"diagnostics":e==="dev_logs"?"logs":"audit";X[s]=t.message||"Não foi possível carregar os dados desta aba."}},async refreshDeveloperPanel(){(i==null?void 0:i.role)==="dev"&&(await this.loadDeveloperPanel(v),this.renderCurrentView())},async exportDeveloperData(){var s;if((i==null?void 0:i.role)!=="dev")return;const e=(s=document.getElementById("dev-export-resource"))==null?void 0:s.value;if(!e)return u("Selecione uma tabela para exportar.");if(await u("O CSV pode conter informações pessoais. Guarde o arquivo em local seguro e compartilhe apenas com pessoas autorizadas. Deseja continuar?",{confirm:!0,title:"Confirmar exportação"}))try{const a=await f.get(`/api/dev/export/${encodeURIComponent(e)}`),l={users:["uid","email","displayName","role","school_id","subject"],schools:["id","name","createdAt"],schedules:["id","date","startTime","endTime","subject","room","teacherId","teacherName","classGroup","turno","status","school_id"],school_periods:["id","school_id","turno","periodNumber","name","startTime","endTime"],lab_bookings:["id","labId","teacherId","teacherName","date","startTime","endTime"],school_subjects:["id","school_id","subject"],teacher_subjects:["id","teacher_id","subject_id"]}[e],r=x=>{const h=x==null?"":typeof x=="object"?JSON.stringify(x):String(x);return`"${(/^[\s]*[=+\-@]/.test(h)?`'${h}`:h).replace(/"/g,'""')}"`},d=[l.map(r).join(","),...a.rows.map(x=>l.map(h=>r(x[h])).join(","))].join(`\r
`),c=new Blob(["\uFEFF",d],{type:"text/csv;charset=utf-8"}),n=URL.createObjectURL(c),m=document.createElement("a");m.href=n,m.download=`studia-${e}-${new Date().toISOString().slice(0,10)}.csv`,document.body.appendChild(m),m.click(),m.remove(),setTimeout(()=>URL.revokeObjectURL(n),1e3),u(`Exportação concluída: ${a.count} registros.`)}catch(a){u(a.message||"Não foi possível exportar os dados.")}},async login(){const e=p("#auth-email"),t=p("#auth-password");if(!e||!t)return;const s=e.value,a=t.value;if(!s||!a)return u("Por favor, preencha todos os campos.");try{i=await f.post("/api/auth/login",{email:s,password:a}),localStorage.setItem("user",JSON.stringify(i)),D="closed",this.init()}catch(o){u(o.message)}},async register(){const e=p("#auth-email"),t=p("#auth-password"),s=p("#auth-name");if(!e||!t||!s)return;const a=e.value.trim(),o=t.value,l=s.value.trim();if(!a||!o||!l)return u("Por favor, preencha todos os campos.");if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(a))return u("E-mail inválido. Use um endereço válido.");try{i=await f.post("/api/auth/register",{email:a,password:o,displayName:l}),localStorage.setItem("user",JSON.stringify(i)),D="closed",this.init()}catch(d){u(d.message)}},logout(){localStorage.removeItem("user"),i=null,v="horarios",D="closed",this.init()},showAddMatériaModal(){const e=prompt("Informe a matéria que você leciona:");e&&this.addMatéria(e)},async addMatéria(e){if(!(!i||!i.uid))try{const t=await f.post(`/api/teachers/${i.uid}/subjects`,{subject:e});window.teacherSubjects||(window.teacherSubjects=[]),window.teacherSubjects.push(t),W(xe()),lucide.createIcons()}catch(t){u(t.message)}},async deleteMatéria(e){if(!(!i||!i.uid)&&confirm(`Deseja remover a matéria "${e}"?`))try{await f.delete(`/api/teachers/${i.uid}/subjects/${encodeURIComponent(e)}`),window.teacherSubjects=(window.teacherSubjects||[]).filter(t=>t.subject!==e),W(xe()),lucide.createIcons()}catch(t){u(t.message)}},normalizeSchedules(e){return e.map(t=>{const s=t.classgroup||t.classGroup||"SEM_TURMA";return(!s||s.trim()==="")&&console.warn("[WARN] Schedule sem classGroup:",t),{id:t.id,date:t.date,startTime:t.starttime||t.startTime,endTime:t.endtime||t.endTime,subject:t.subject,room:t.room,turno:t.turno,teacherId:t.teacherid||t.teacherId,teacherName:t.teachername||t.teacherName,classGroup:s,status:t.status,school_id:t.school_id,createdAt:t.createdat||t.createdAt}})},async refreshData(){var e,t;if(!(!i||he)){he=!0;try{if(i.role==="dev"){G=[],Y="";const s=await Promise.allSettled([f.get(i.school_id?`/api/schedules?schoolId=${i.school_id}`:"/api/schedules"),f.get("/api/teachers"),f.get("/api/users"),f.get("/api/labs/bookings"),f.get("/api/schools"),f.get("/api/school-subjects")]),[a,o,l,r,d,c]=s.map((n,m)=>n.status==="fulfilled"?n.value:(console.error(`Data fetch #${m} failed:`,n.reason),[]));$=this.normalizeSchedules(a||[]),O=o||[],_=l||[],R=d||[],V=c||[],R.some(n=>n.id===oe)||(oe=i.school_id||((e=R[0])==null?void 0:e.id)||""),E={total:$.length,confirmed:$.filter(n=>n.status==="confirmed").length,absent:$.filter(n=>n.status==="absent").length,pending:$.filter(n=>n.status==="pending").length},U=r||[]}else if(i.role==="diretor"){const s=await Promise.allSettled([f.get(`/api/schedules?schoolId=${i.school_id}`),f.get("/api/teachers"),f.get(`/api/users?schoolId=${i.school_id}`),f.get("/api/labs/bookings"),f.get("/api/school-subjects"),f.get("/api/school-periods")]),[a,o,l,r,d]=s.slice(0,5).map((n,m)=>n.status==="fulfilled"?n.value:(console.error(`Data fetch #${m} failed:`,n.reason),[])),c=s[5];G=c.status==="fulfilled"?c.value:[],c.status==="rejected"?(console.error("School periods fetch failed:",c.reason),Y=((t=c.reason)==null?void 0:t.message)||"Não foi possível carregar os períodos."):Y="",$=this.normalizeSchedules(a||[]),O=o||[],_=l||[],V=d||[],E={total:$.length,confirmed:$.filter(n=>n.status==="confirmed").length,absent:$.filter(n=>n.status==="absent").length,pending:$.filter(n=>n.status==="pending").length},U=r||[]}else{G=[],Y="";const s=await Promise.allSettled([f.get(`/api/schedules?teacherId=${i.uid}`),f.get("/api/labs/bookings"),f.get(`/api/teachers/${i.uid}/subjects`),f.get("/api/school-subjects")]),[a,o,l,r]=s.map((d,c)=>d.status==="fulfilled"?d.value:(console.error(`Data fetch #${c} failed:`,d.reason),[]));$=this.normalizeSchedules(a||[]),_=[],V=r||[],U=o||[],window.teacherSubjects=l||[]}}catch(s){console.error("Data refresh error:",s)}finally{he=!1}}},async refreshSchedules(){await this.refreshData(),this.init()},toggleUserSelection(e,t){!e||e===(i==null?void 0:i.uid)||!_.some(s=>s.uid===e)||(t?F.add(e):F.delete(e),this.renderCurrentView())},toggleAllUsers(e){const t=_.filter(s=>s.uid!==(i==null?void 0:i.uid));e?t.forEach(s=>F.add(s.uid)):t.forEach(s=>F.delete(s.uid)),this.renderCurrentView()},toggleTeacherSubjectsEditor(e){ue=ue===e?null:e,this.renderCurrentView()},async assignTeacherSchool(e){var s;const t=(s=document.getElementById(`teacher-school-${e}`))==null?void 0:s.value;if(!t)return u("Selecione uma escola para continuar.");try{await f.patch(`/api/users/${e}/school`,{schoolId:t}),await this.refreshData(),this.renderCurrentView()}catch(a){u(a.message||"Não foi possível associar o professor à escola.")}},closeTeacherSubjectsEditor(){ue=null,this.renderCurrentView()},async deleteUser(e,t,s){if(!(!e||!await u(`Deseja excluir ${t} (${s}) do sistema? Essa ação remove o acesso do usuário e sua conta de autenticação.`,{confirm:!0,title:"Excluir usuário"})))try{await f.delete(`/api/users/${e}`),F.delete(e),await this.refreshData(),this.init(),u("Usuário excluído com sucesso.")}catch(o){u(o.message||"Erro ao excluir usuário.")}},async deleteSelectedUsers(){const e=_.filter(o=>F.has(o.uid)&&o.uid!==(i==null?void 0:i.uid));if(e.length===0)return;const t=e.map(o=>o.email||o.displayName||o.uid).join(`
`);if(!await u(`Confirma excluir ${e.length} conta${e.length===1?"":"s"}? Esta ação não pode ser desfeita.

${t}`,{confirm:!0,title:"Excluir contas selecionadas"}))return;const a=[];for(const o of e)try{await f.delete(`/api/users/${o.uid}`),F.delete(o.uid)}catch(l){a.push(`${o.email||o.displayName||o.uid}: ${l.message||"falha ao excluir"}`)}await this.refreshData(),this.renderCurrentView(),a.length>0?u(`Não foi possível excluir todas as contas. As contas com erro continuam selecionadas para você tentar novamente:

${a.join(`
`)}`,{title:"Exclusão parcial"}):u(`${e.length} conta${e.length===1?"":"s"} excluída${e.length===1?"":"s"} com sucesso.`)},selectSubjectSchool(e){oe=e,this.renderCurrentView()},async createSchoolSubject(e){var o;e.preventDefault();const t=p("#school-subject-name"),s=(i==null?void 0:i.role)==="diretor"?i.school_id:oe||(i==null?void 0:i.school_id),a=(o=t==null?void 0:t.value)==null?void 0:o.trim();if(!s||!a)return u("Selecione uma escola e informe a matéria.");try{await f.post("/api/school-subjects",{schoolId:s,subject:a}),await this.refreshData(),this.renderCurrentView()}catch(l){u(l.message||"Erro ao adicionar matéria.")}},async deleteSchoolSubject(e){const t=V.find(a=>String(a.id)===String(e));if(!t){u("Não foi possível localizar essa matéria. Atualize a página e tente novamente.");return}if(await u(`Excluir "${t.subject}" do catálogo? Os horários antigos serão mantidos, mas os vínculos com professores serão removidos.`,{confirm:!0,title:"Excluir matéria"}))try{await f.delete(`/api/school-subjects/${e}`),await this.refreshData(),this.renderCurrentView()}catch(a){u(a.message||"Erro ao excluir matéria.")}},async setTeacherSubject(e,t,s){try{s?await f.post(`/api/school-subjects/${e}/teachers`,{teacherId:t}):await f.delete(`/api/school-subjects/${e}/teachers/${t}`),await this.refreshData(),this.renderCurrentView()}catch(a){await this.refreshData(),this.renderCurrentView(),u(a.message||"Erro ao atualizar vínculo da matéria.")}},async changeUserRole(e,t){if(!(!e||e===(i==null?void 0:i.uid)))try{await f.patch(`/api/users/${e}/role`,{role:t}),_=_.map(s=>s.uid===e?{...s,role:t}:s),this.init()}catch(s){u(s.message||"Erro ao atualizar perfil do usuário."),this.init()}},async updateStatus(e,t){try{await f.patch(`/api/schedules/${e}`,{status:t}),this.init()}catch{u("Erro ao atualizar status.")}},async createSchedule(e){var n,m,x,h,k;e.preventDefault();const t=p("#form-teacher"),s=((n=p("#form-schedule-mode"))==null?void 0:n.value)||"weekly",a=((m=p("#form-turno"))==null?void 0:m.value)||"manha",o=Array.from(document.querySelectorAll('input[name="form-period"]:checked')).map(b=>Number(b.value));if(o.length===0)return u("Selecione pelo menos um período.");let l,r,d;if(s==="single"){if(l=(x=p("#form-date"))==null?void 0:x.value,r=l,!l)return u("Informe a data da aula.");const b=ie(l).getDay();if(b<1||b>5)return u("A data selecionada precisa ser de segunda a sexta-feira.");d=[b]}else{if(l=(h=p("#form-start-date"))==null?void 0:h.value,r=(k=p("#form-end-date"))==null?void 0:k.value,d=Array.from(document.querySelectorAll('input[name="form-weekday"]:checked')).map(b=>Number(b.value)),!l||!r||l>r)return u("Informe um intervalo de datas válido.");if(d.length===0)return u("Selecione pelo menos um dia da semana.")}const c={subject:p("#form-subject").value.trim(),classGroup:p("#form-class-group").value.trim(),room:p("#form-room").value.trim(),teacherId:t.value,turno:a,startDate:l,endDate:r,weekdayNumbers:d,periodNumbers:o};try{const b=await f.post("/api/schedules/recurring",c);this.hideCreateModal(),await this.init(),u(`${b.created} horário${b.created===1?"":"s"} criado${b.created===1?"":"s"} com sucesso.`)}catch(b){u(b.message||"Erro ao criar horário.")}},async updateSchedule(e){e.preventDefault();const t=p("#edit-form-id").value,s=p("#edit-form-teacher"),a={subject:p("#edit-form-subject").value,classGroup:p("#edit-form-class-group").value,date:p("#edit-form-date").value,room:p("#edit-form-room").value,turno:p("#edit-form-turno").value,startTime:p("#edit-form-start").value,endTime:p("#edit-form-end").value,teacherId:s.value,teacherName:s.options[s.selectedIndex].text,status:p("#edit-form-status").value};try{await f.patch(`/api/schedules/${t}`,a),this.hideEditModal(),await this.init(),u("Horário atualizado com sucesso.")}catch(o){u(o.message||"Erro ao editar horário.")}},async deleteAllSchedules(){const e=te($,M);if(e.length===0)return;const t=M==="todos"?"todos os horários da escola, de todos os turnos":`todos os horários da escola no turno da ${Z[M]}`;if(!await u(`Esta ação excluirá ${e.length} horário${e.length===1?"":"s"} (${t}) e não poderá ser desfeita. Deseja continuar?`,{confirm:!0,title:"Remover horários"}))return;const a=M==="todos"?"":`?turno=${encodeURIComponent(M)}`;try{const o=await f.delete(`/api/schedules${a}`);await this.init(),u(`${o.deleted} horário${o.deleted===1?"":"s"} removido${o.deleted===1?"":"s"}.`)}catch(o){u(o.message||"Não foi possível remover os horários.")}},async deleteSchedule(e){if(await u("Deseja excluir este horário?",{confirm:!0,title:"Excluir horário"}))try{await f.delete(`/api/schedules/${e}`),this.init()}catch(t){u(t.message||"Erro ao excluir.")}},async createLabBooking(e){e.preventDefault();const t={labId:p("#lab-type").value,date:p("#lab-date").value,startTime:p("#lab-start").value,endTime:p("#lab-end").value};if(t.startTime>=t.endTime){u("O horário de término precisa ser depois do horário de início.");return}if(U.some(a=>a.labId===t.labId&&a.date===t.date&&t.startTime<a.endTime.slice(0,5)&&t.endTime>a.startTime.slice(0,5))){u("Este laboratório já está reservado em parte ou em todo esse horário.");return}try{await f.post("/api/labs/bookings",t),this.hideLabModal(),this.init()}catch(a){u(a.message||"Não foi possível criar a reserva.")}},setLabFilter(e,t){A={...A,[e]:t},this.renderCurrentView()},async deleteLabBooking(e){if(await u("Deseja realmente cancelar esta reserva de laboratório?",{confirm:!0,title:"Cancelar reserva"}))try{await f.delete(`/api/labs/bookings/${e}`),U=U.filter(t=>String(t.id)!==String(e)),await this.refreshData(),this.init()}catch(t){u(t.message||"Não foi possível cancelar a reserva.")}},nextSlide(){ce<yt.length-1&&(ce++,this.init())},prevSlide(){ce>0&&(ce--,this.init())},setReportWeek(e){P=e,this.renderCurrentView()},setReportTeacher(e){J=e,this.renderCurrentView()},setReportCardSize(e){w=e,localStorage.setItem("reportCardSize",e),this.renderCurrentView()},setSchoolName(e){le=e;const t=p(".printable-sheet h4");t&&(t.textContent=e)},setRelatorioSubTab(e){me=e,this.renderCurrentView()},setReportModel(e){H=e,this.renderCurrentView()},setTeacherSchedulesTab(e){e==="grid"&&(we="grid",this.renderCurrentView())},async downloadTeacherPDF(){const e=document.querySelector(".printable-sheet");if(!e)return;const t=document.querySelector("#btn-download-pdf-teacher"),s=t?t.innerHTML:"";t&&(t.innerHTML='<svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white inline" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> Gerando PDF...',t.disabled=!0);const a=e.cloneNode(!0);a.id="temp-pdf-teacher-container",a.className="printable-sheet bg-white",a.style.width="1020px",a.style.boxSizing="border-box",a.style.backgroundColor="#ffffff",a.style.padding="30px",document.body.appendChild(a),typeof lucide<"u"&&lucide.createIcons({node:a});const o={margin:[.3,.3,.3,.3],filename:`Grade_Professor_${i?i.displayName.replace(/\s+/g,"_"):"Individual"}.pdf`,image:{type:"jpeg",quality:.98},html2canvas:{scale:2,useCORS:!0,logging:!1,backgroundColor:"#ffffff"},jsPDF:{unit:"in",format:"a4",orientation:"landscape"}},l=Re(a);let r=()=>{};try{r=await ze()}catch(d){console.warn("Could not clean stylesheets:",d)}html2pdf().set(o).from(a).save().then(()=>{l(),r(),document.body.removeChild(a),t&&(t.innerHTML=s,t.disabled=!1,typeof lucide<"u"&&lucide.createIcons())}).catch(d=>{l(),r(),document.getElementById("temp-pdf-teacher-container")&&document.body.removeChild(a),console.error("Error generating PDF:",d),t&&(t.innerHTML=s,t.disabled=!1,typeof lucide<"u"&&lucide.createIcons()),u("Houve um erro ao gerar o PDF.")})},async downloadPDF(){if(!document.querySelector(".printable-sheet"))return;const t=document.querySelector("#btn-download-pdf"),s=t?t.innerHTML:"";t&&(t.innerHTML='<svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white inline" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> Gerando PDF...',t.disabled=!0);let a=$;P!=="all"&&(a=$.filter(g=>{try{return Ce(g.date)===P}catch{return!1}})),a=te(a,B);let o=O;if(J!=="all"&&(o=O.filter(g=>g.uid===J)),o.length===0&&a.length>0){const g=new Set,S=[];a.forEach(j=>{j.teacherId&&!g.has(j.teacherId)&&(g.add(j.teacherId),S.push({uid:j.teacherId,displayName:j.teacherName,subject:j.subject}))}),o=S}const l=je(a);let r=[];const d=H==="turma_grid";d?r=Xe(a):r=o;const n={small:8,medium:4,large:3,esticado:2,super_esticado:1}[w]||4,m=[];for(let g=0;g<r.length;g+=n)m.push(r.slice(g,g+n));const x=document.createElement("div");x.id="temp-pdf-container",x.className="printable-sheet bg-white",x.style.width="1020px",x.style.padding="10px",x.style.boxSizing="border-box",x.style.backgroundColor="#ffffff";let h="grid grid-cols-2 gap-4 justify-center w-full";w==="small"?h="grid grid-cols-4 gap-2 justify-center w-full":w==="medium"?h="grid grid-cols-2 gap-4 justify-center w-full":w==="large"?h="grid grid-cols-3 gap-4 justify-center w-full":w==="esticado"?h="grid grid-cols-2 gap-4 justify-center w-full":w==="super_esticado"&&(h="grid grid-cols-1 gap-6 justify-center w-full");let k="";m.forEach((g,S)=>{const j=`
        <div class="flex justify-between items-center border-b border-blue-100 pb-4 mb-6 gap-4">
          <div class="flex items-center gap-4">
            <svg width="240" height="65" viewBox="0 0 240 65" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: block;">
              <path d="M10 24C45 6, 85 45, 128 35C155 28, 175 14, 235 22" stroke="#7ec2f2" stroke-width="2.8" stroke-linecap="round" fill="none" opacity="0.8"/>
              <path d="M124 35C136 43, 155 35, 150 24C145 15, 132 18, 126 27" stroke="#3b82f6" stroke-width="2" stroke-linecap="round" fill="none" opacity="0.9"/>
              <path d="M175 14C195 6, 215 16, 235 22" stroke="#7ec2f2" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round" fill="none" opacity="0.3"/>
              <g transform="translate(68, 2)">
                <path d="M15 14C15 6, 25 3, 30 7.5L30 23C25 18, 15 19, 15 22Z" fill="#5B99C2" />
                <path d="M45 14C45 6, 35 3, 30 7.5L30 23C35 18, 45 19, 45 22Z" fill="#2E5077" />
                <path d="M18 16C18 13, 24 10, 27 12L27 21" stroke="white" stroke-width="0.8" opacity="0.4" fill="none"/>
                <path d="M42 16C42 13, 36 10, 33 12L33 21" stroke="white" stroke-width="0.8" opacity="0.4" fill="none"/>
              </g>
              <text x="18" y="47" font-family="'Inter', sans-serif" font-weight="800" font-size="34" fill="#2E5077" letter-spacing="-1.5">Studia</text>
              <text x="21" y="58" font-family="'Inter', sans-serif" font-weight="700" font-size="8.5" fill="#5B99C2" letter-spacing="1.2">GRADE ESCOLAR DIGITAL</text>
            </svg>
          </div>
          <div class="text-right">
            <h4 class="text-xs font-black text-slate-800 uppercase tracking-wide">${le}</h4>
            <p class="text-[9px] text-slate-400 font-extrabold uppercase tracking-widest mt-0.5">
              ${d?"Relatório de Turmas (Individual)":"Relatório de Professores (Individual)"} - ${P==="all"?"Grade Geral Acumulada":$e(P)} - ${B==="todos"?"Todos os turnos":Z[B]}
            </p>
          </div>
        </div>
      `,q=g.map(L=>{if(d){const ae=a.filter(fe=>fe.classGroup===L);return Oe(L,ae,l)}else{const ae=a.filter(fe=>fe.teacherId===L.uid);return Me(L,ae,l,H)}}).join(""),N=`
        <div class="border-t border-slate-100 mt-6 pt-3 flex justify-between text-[8px] text-slate-400 font-extrabold uppercase tracking-widest leading-none">
          <span>Página ${S+1} de ${m.length}</span>
          <span>Data de emissão: ${new Date().toLocaleDateString("pt-BR")}</span>
        </div>
      `,se=S===m.length-1?"":"page-break-after: always;";k+=`
        <div class="pdf-page bg-white" style="${se} width: 100%; box-sizing: border-box; padding-bottom: 20px;">
          ${j}
          <div class="${h}">
            ${q}
          </div>
          ${N}
        </div>
      `}),x.innerHTML=k,document.body.appendChild(x),typeof lucide<"u"&&lucide.createIcons({node:x});const b={margin:[.2,.2,.2,.2],filename:`Grade_Escolar_${P}.pdf`,image:{type:"jpeg",quality:.98},html2canvas:{scale:2,useCORS:!0,logging:!1,backgroundColor:"#ffffff"},jsPDF:{unit:"in",format:"a4",orientation:"landscape"},pagebreak:{mode:["avoid-all","css","legacy"]}},C=Re(x);let y=()=>{};try{y=await ze()}catch(g){console.warn("Could not clean stylesheets:",g)}html2pdf().set(b).from(x).save().then(()=>{C(),y(),document.body.removeChild(x),t&&(t.innerHTML=s,t.disabled=!1,typeof lucide<"u"&&lucide.createIcons())}).catch(g=>{C(),y(),document.getElementById("temp-pdf-container")&&document.body.removeChild(x),console.error("Error generating PDF:",g),t&&(t.innerHTML=s,t.disabled=!1,typeof lucide<"u"&&lucide.createIcons()),u("Houve um erro ao gerar o PDF.")})},showCreateEscolaModal(){const e=document.getElementById("create-escola-modal");e&&e.classList.remove("hidden")},hideCreateEscolaModal(){var t;const e=document.getElementById("create-escola-modal");e&&e.classList.add("hidden"),(t=document.getElementById("escola-name"))!=null&&t.value&&(document.getElementById("escola-name").value="")},async createSchool(e){var s;e&&e.preventDefault();const t=(s=document.getElementById("escola-name"))==null?void 0:s.value;if(!t)return u("Nome da escola é obrigatório.");try{await f.post("/api/schools",{name:t,createdBy:i.uid}),this.hideCreateEscolaModal(),await this.refreshData(),this.init(),u("Escola criada com sucesso!")}catch(a){u(a.message||"Erro ao criar escola.")}},async deleteSchool(e){if(!e)return;const t=R.find(a=>a.id===e);if(await u(`Deseja excluir a escola "${t==null?void 0:t.name}"? Esta ação não pode ser desfeita.`,{confirm:!0,title:"Excluir escola"}))try{await f.delete(`/api/schools/${e}`),await this.refreshData(),this.init(),u("Escola excluída com sucesso.")}catch(a){u(a.message||"Erro ao excluir escola.")}},showCreateUserModal(e="dev"){const t=document.getElementById("create-user-modal");t&&t.classList.remove("hidden")},hideCreateUserModal(){var t,s,a,o,l,r;const e=document.getElementById("create-user-modal");e&&e.classList.add("hidden"),(t=document.getElementById("user-displayname"))!=null&&t.value&&(document.getElementById("user-displayname").value=""),(s=document.getElementById("user-email"))!=null&&s.value&&(document.getElementById("user-email").value=""),(a=document.getElementById("user-password"))!=null&&a.value&&(document.getElementById("user-password").value=""),(o=document.getElementById("user-subject"))!=null&&o.value&&(document.getElementById("user-subject").value=""),(l=document.getElementById("user-school"))!=null&&l.value&&(document.getElementById("user-school").value=""),(r=document.getElementById("user-role"))!=null&&r.value&&(document.getElementById("user-role").value="")},async createUser(e){var c,n,m,x,h,k,b,C,y;e&&e.preventDefault();const t=(n=(c=document.getElementById("user-displayname"))==null?void 0:c.value)==null?void 0:n.trim(),s=(x=(m=document.getElementById("user-email"))==null?void 0:m.value)==null?void 0:x.trim(),a=(h=document.getElementById("user-password"))==null?void 0:h.value,o=(b=(k=document.getElementById("user-subject"))==null?void 0:k.value)==null?void 0:b.trim(),l=(C=document.getElementById("user-role"))==null?void 0:C.value,r=(y=document.getElementById("user-school"))==null?void 0:y.value;if(!t)return u("Nome é obrigatório.");if(!s)return u("E-mail é obrigatório.");if(!a)return u("Senha é obrigatória.");if(a.length<8)return u("Senha deve ter no mínimo 8 caracteres.");if(!l)return u("Cargo é obrigatório.");if((i==null?void 0:i.role)==="dev"&&!r)return u("Selecione a escola do usuário.");if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s))return u("E-mail inválido. Use um endereço válido.");try{const g={displayName:t,email:s,password:a,role:l,schoolId:r,userRole:i==null?void 0:i.role,userSchoolId:i==null?void 0:i.school_id};o&&(g.subject=o),await f.post("/api/users/create",g),this.hideCreateUserModal(),await this.refreshData(),this.init(),u("Usuário criado com sucesso!")}catch(g){const S=g.message||"Erro ao criar usuário.";u(S)}}};function Ze(e){try{const t=e.match(/oklch\(([^)]+)\)/i);if(!t)return"rgb(0, 0, 0)";const s=t[1].trim().split(/[\s,+/]+/);if(s.length<3)return"rgb(0, 0, 0)";let a=s[0].endsWith("%")?parseFloat(s[0])/100:parseFloat(s[0]),o=s[1].endsWith("%")?parseFloat(s[1])/100*.4:parseFloat(s[1]),l=0;s[2]!=="none"&&(s[2].endsWith("deg")?l=parseFloat(s[2]):s[2].endsWith("rad")?l=parseFloat(s[2])*180/Math.PI:s[2].endsWith("turn")?l=parseFloat(s[2])*360:l=parseFloat(s[2]));let r=1;s[3]!==void 0&&(r=s[3].endsWith("%")?parseFloat(s[3])/100:parseFloat(s[3]));const d=o*Math.cos(l*Math.PI/180),c=o*Math.sin(l*Math.PI/180),n=a+.3963377774*d+.2158037573*c,m=a-.1055613458*d-.0638541728*c,x=a-.0894841775*d-1.291485548*c,h=Math.pow(Math.max(0,n),3),k=Math.pow(Math.max(0,m),3),b=Math.pow(Math.max(0,x),3);let C=4.0767416621*h-3.3077115913*k+.2309699292*b,y=-1.2684380046*h+2.6097574011*k-.3413193965*b,g=-.0041960863*h-.7034186147*k+1.707614701*b;const S=C<=.0031308?12.92*C:1.055*Math.pow(C,1/2.4)-.055,j=y<=.0031308?12.92*y:1.055*Math.pow(y,1/2.4)-.055,q=g<=.0031308?12.92*g:1.055*Math.pow(g,1/2.4)-.055,N=se=>Math.min(255,Math.max(0,Math.round(se*255)));return r===1?`rgb(${N(S)}, ${N(j)}, ${N(q)})`:`rgba(${N(S)}, ${N(j)}, ${N(q)}, ${r})`}catch{return"rgb(0, 0, 0)"}}function Se(e){return!e||typeof e!="string"||!e.includes("oklch")?e:e.replace(/oklch\([^)]+\)/gi,t=>{let s=document.getElementById("temp-color-resolver");s||(s=document.createElement("div"),s.id="temp-color-resolver",s.style.position="absolute",s.style.visibility="hidden",s.style.width="0",s.style.height="0",document.body.appendChild(s));try{s.style.color=t;const a=window.getComputedStyle(s,null).getPropertyValue("color");if(a&&!a.includes("oklch"))return a}catch{}return Ze(t)})}async function ze(){const e=[],t=Array.from(document.querySelectorAll('style, link[rel="stylesheet"]'));let s="";for(const l of t)try{if(l.tagName==="STYLE")s+=`
`+l.innerHTML,e.push({node:l,originalDisabled:l.disabled,type:"style"});else if(l.tagName==="LINK"){let r="";try{if(l.sheet){const d=l.sheet.cssRules||l.sheet.rules;for(let c=0;c<d.length;c++)r+=d[c].cssText+`
`}}catch{}if(!r){const d=l.getAttribute("href");d&&(d.startsWith("/")||d.startsWith("./")||d.startsWith("src/")||d.startsWith(window.location.origin))&&(r=await(await fetch(d)).text())}r&&(s+=`
`+r,e.push({node:l,originalDisabled:l.disabled,type:"link"}))}}catch(r){console.warn("Could not backup or read stylesheet:",l,r)}const a=s.replace(/oklch\([^)]+\)/gi,l=>Ze(l)),o=document.createElement("style");o.id="temp-cleaned-stylesheets",o.innerHTML=a,document.head.appendChild(o);for(const l of e)l.node.disabled=!0;return function(){for(const r of e)r.node.disabled=r.originalDisabled;o.parentNode&&o.parentNode.removeChild(o)}}function Re(e){const t=$t(),s=[e,...e.querySelectorAll("*")],a=[];for(const o of s){if(!o||!o.style)continue;const l=o.getAttribute("style")||"";a.push({el:o,originalInlineStyle:l});try{const r=window.getComputedStyle(o),d=["color","backgroundColor","borderColor","borderTopColor","borderBottomColor","borderLeftColor","borderRightColor","stroke","fill"];for(const c of d){let n="";try{n=r.getPropertyValue(c.replace(/([A-Z])/g,"-$1").toLowerCase())}catch{n=r[c]}if(n&&typeof n=="string"&&n.includes("oklch")){const m=Se(n);o.style[c]=m}}}catch{}}return function(){t();for(const l of a)l.originalInlineStyle?l.el.setAttribute("style",l.originalInlineStyle):l.el.removeAttribute("style")}}function $t(){const e=CSSStyleDeclaration.prototype.getPropertyValue;CSSStyleDeclaration.prototype.getPropertyValue=function(a){const o=e.call(this,a);return o&&typeof o=="string"&&o.includes("oklch")?Se(o):o};const t=["color","backgroundColor","borderColor","borderTopColor","borderBottomColor","borderLeftColor","borderRightColor","stroke","fill"],s={};for(const a of t){const o=Object.getOwnPropertyDescriptor(CSSStyleDeclaration.prototype,a);o&&o.get&&(s[a]=o,Object.defineProperty(CSSStyleDeclaration.prototype,a,{configurable:!0,enumerable:!0,get(){const l=o.get.call(this);return l&&typeof l=="string"&&l.includes("oklch")?Se(l):l},set(l){o.set.call(this,l)}}))}return function(){CSSStyleDeclaration.prototype.getPropertyValue=e;for(const o in s)Object.defineProperty(CSSStyleDeclaration.prototype,o,s[o])}}window.actions=Je;Je.init();
